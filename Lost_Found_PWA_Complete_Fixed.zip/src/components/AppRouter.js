// Application Router for Lost & Found PWA
export class AppRouter {
  constructor() {
    this.routes = new Map();
    this.currentRoute = null;
    this.params = {};
    this.query = {};
    
    this.setupRoutes();
  }

  setupRoutes() {
    // Define all application routes
    this.routes.set('/', () => import('./pages/HomePage.js'));
    this.routes.set('/login', () => import('./pages/LoginPage.js'));
    this.routes.set('/register', () => import('./pages/RegisterPage.js'));
    this.routes.set('/dashboard', () => import('./pages/DashboardPage.js'));
    this.routes.set('/report', () => import('./pages/ReportItemPage.js'));
    this.routes.set('/search', () => import('./pages/SearchPage.js'));
    this.routes.set('/item/:id', () => import('./pages/ItemDetailPage.js'));
    this.routes.set('/profile', () => import('./pages/ProfilePage.js'));
    this.routes.set('/messages', () => import('./pages/MessagesPage.js'));
    this.routes.set('/admin', () => import('./pages/AdminPage.js'));
    this.routes.set('/analytics', () => import('./pages/AnalyticsPage.js'));
    this.routes.set('/settings', () => import('./pages/SettingsPage.js'));
    this.routes.set('/help', () => import('./pages/HelpPage.js'));
    this.routes.set('/offline', () => import('./pages/OfflinePage.js'));
    this.routes.set('/404', () => import('./pages/NotFoundPage.js'));
  }

  async init() {
    // Setup event listeners
    window.addEventListener('popstate', (event) => {
      this.handleRouteChange(event.state);
    });

    // Handle initial route
    await this.handleRouteChange();
    
    // Setup navigation interceptor
    this.setupNavigationInterceptor();
  }

  setupNavigationInterceptor() {
    // Intercept all link clicks for SPA navigation
    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href]');
      
      if (link && this.shouldInterceptNavigation(link)) {
        event.preventDefault();
        const href = link.getAttribute('href');
        this.navigate(href);
      }
    });
  }

  shouldInterceptNavigation(link) {
    const href = link.getAttribute('href');
    
    // Don't intercept external links
    if (href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:')) {
      return false;
    }
    
    // Don't intercept links with target="_blank"
    if (link.getAttribute('target') === '_blank') {
      return false;
    }
    
    // Don't intercept download links
    if (link.hasAttribute('download')) {
      return false;
    }
    
    return true;
  }

  async navigate(path, replace = false) {
    try {
      // Update browser history
      if (replace) {
        history.replaceState({ path }, '', path);
      } else {
        history.pushState({ path }, '', path);
      }
      
      // Handle route change
      await this.handleRouteChange({ path });
      
    } catch (error) {
      console.error('Navigation error:', error);
      this.navigate('/404', true);
    }
  }

  async handleRouteChange(state = null) {
    const path = state?.path || window.location.pathname;
    const search = window.location.search;
    
    // Parse route and parameters
    const { route, params } = this.parseRoute(path);
    this.params = params;
    this.query = this.parseQuery(search);
    
    // Check if route exists
    if (!this.routes.has(route)) {
      await this.navigate('/404', true);
      return;
    }
    
    try {
      // Show loading state
      this.showLoadingState();
      
      // Load and render the page component
      const pageModule = await this.routes.get(route)();
      const PageComponent = pageModule.default || pageModule[Object.keys(pageModule)[0]];
      
      // Create page instance
      const pageInstance = new PageComponent({
        params: this.params,
        query: this.query,
        router: this
      });
      
      // Render the page
      await this.renderPage(pageInstance);
      
      // Update current route
      this.currentRoute = route;
      
      // Update page title and meta
      this.updatePageMeta(pageInstance);
      
      // Track page view
      if (window.LostFoundApp?.analytics) {
        window.LostFoundApp.analytics.track('page_view', {
          path,
          route,
          params: this.params,
          query: this.query
        });
      }
      
    } catch (error) {
      console.error('Route handling error:', error);
      this.showErrorState(error);
    }
  }

  parseRoute(path) {
    // Remove trailing slash
    const cleanPath = path.replace(/\/$/, '') || '/';
    
    // Check for exact matches first
    if (this.routes.has(cleanPath)) {
      return { route: cleanPath, params: {} };
    }
    
    // Check for parameterized routes
    for (const [routePattern] of this.routes) {
      const { isMatch, params } = this.matchRoute(routePattern, cleanPath);
      if (isMatch) {
        return { route: routePattern, params };
      }
    }
    
    return { route: '/404', params: {} };
  }

  matchRoute(pattern, path) {
    // Convert route pattern to regex
    const paramNames = [];
    const regexPattern = pattern.replace(/:([^/]+)/g, (match, paramName) => {
      paramNames.push(paramName);
      return '([^/]+)';
    });
    
    const regex = new RegExp(`^${regexPattern}$`);
    const match = path.match(regex);
    
    if (!match) {
      return { isMatch: false, params: {} };
    }
    
    // Extract parameters
    const params = {};
    paramNames.forEach((name, index) => {
      params[name] = decodeURIComponent(match[index + 1]);
    });
    
    return { isMatch: true, params };
  }

  parseQuery(search) {
    const query = {};
    const params = new URLSearchParams(search);
    
    for (const [key, value] of params) {
      query[key] = value;
    }
    
    return query;
  }

  async renderPage(pageInstance) {
    const appContainer = document.getElementById('app');
    
    // Clear previous content
    appContainer.innerHTML = '';
    
    // Render the page
    const pageElement = await pageInstance.render();
    appContainer.appendChild(pageElement);
    
    // Call page lifecycle methods
    if (pageInstance.onMount) {
      await pageInstance.onMount();
    }
    
    // Store page instance for cleanup
    this.currentPageInstance = pageInstance;
  }

  showLoadingState() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="loading-container">
        <div class="loading-content">
          <div class="spinner"></div>
          <p>Loading...</p>
        </div>
      </div>
    `;
  }

  showErrorState(error) {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="error-container">
        <div class="error-content">
          <i class="fas fa-exclamation-triangle"></i>
          <h2>Page Load Error</h2>
          <p>Failed to load the requested page. Please try again.</p>
          <button class="btn btn-primary retry-btn" onclick="window.location.reload()">
            <i class="fas fa-redo"></i> Retry
          </button>
        </div>
      </div>
    `;
  }

  updatePageMeta(pageInstance) {
    // Update document title
    if (pageInstance.title) {
      document.title = `${pageInstance.title} - Lost & Found`;
    }
    
    // Update meta description
    if (pageInstance.description) {
      let metaDesc = document.querySelector('meta[name="description"]');
      if (!metaDesc) {
        metaDesc = document.createElement('meta');
        metaDesc.name = 'description';
        document.head.appendChild(metaDesc);
      }
      metaDesc.content = pageInstance.description;
    }
    
    // Update canonical URL
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = window.location.href;
  }

  // Navigation helper methods
  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      this.navigate('/');
    }
  }

  goForward() {
    window.history.forward();
  }

  reload() {
    this.handleRouteChange();
  }

  // Route guards
  async requireAuth() {
    const authManager = window.LostFoundApp?.auth;
    if (!authManager || !authManager.isAuthenticated()) {
      await this.navigate('/login');
      return false;
    }
    return true;
  }

  async requireAdmin() {
    const authManager = window.LostFoundApp?.auth;
    if (!authManager || !authManager.isAuthenticated() || !authManager.isAdmin()) {
      await this.navigate('/dashboard');
      return false;
    }
    return true;
  }

  // Utility methods
  getCurrentRoute() {
    return this.currentRoute;
  }

  getParams() {
    return { ...this.params };
  }

  getQuery() {
    return { ...this.query };
  }

  buildUrl(path, params = {}, query = {}) {
    let url = path;
    
    // Replace parameters
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, encodeURIComponent(value));
    });
    
    // Add query parameters
    const queryString = new URLSearchParams(query).toString();
    if (queryString) {
      url += `?${queryString}`;
    }
    
    return url;
  }

  // Cleanup
  destroy() {
    if (this.currentPageInstance && this.currentPageInstance.onUnmount) {
      this.currentPageInstance.onUnmount();
    }
  }
}

// Route helper functions
export function createLink(href, text, className = '') {
  return `<a href="${href}" class="${className}">${text}</a>`;
}

export function createButton(text, onClick, className = 'btn btn-primary') {
  const id = `btn-${Math.random().toString(36).substr(2, 9)}`;
  
  // Store click handler for later binding
  setTimeout(() => {
    const button = document.getElementById(id);
    if (button) {
      button.addEventListener('click', onClick);
    }
  }, 0);
  
  return `<button id="${id}" class="${className}">${text}</button>`;
}

// Navigation helpers
export function navigateTo(path) {
  if (window.LostFoundApp?.router) {
    window.LostFoundApp.router.navigate(path);
  } else {
    window.location.href = path;
  }
}

export function redirectTo(path) {
  if (window.LostFoundApp?.router) {
    window.LostFoundApp.router.navigate(path, true);
  } else {
    window.location.replace(path);
  }
}