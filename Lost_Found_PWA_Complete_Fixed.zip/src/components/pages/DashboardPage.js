// Dashboard Page for Lost & Found PWA
export default class DashboardPage {
  constructor({ params, query, router }) {
    this.params = params;
    this.query = query;
    this.router = router;
    this.title = 'Dashboard';
    this.description = 'Manage your lost and found items';
    this.activeTab = this.query.tab || 'overview';
    this.data = {
      summary: {},
      items: [],
      matches: [],
      messages: []
    };
  }

  async render() {
    const container = document.createElement('div');
    container.className = 'dashboard-page';
    
    container.innerHTML = `
      ${this.renderHeader()}
      ${this.renderTabs()}
      ${this.renderContent()}
    `;

    return container;
  }

  renderHeader() {
    return `
      <div class="dashboard-header">
        <div class="container">
          <div class="header-content">
            <div class="header-text">
              <h1>Dashboard</h1>
              <p>Manage your lost and found items</p>
            </div>
            
            <div class="header-actions">
              <a href="/report?type=lost" class="btn btn-primary">
                <i class="fas fa-minus-circle"></i>
                Report Lost Item
              </a>
              <a href="/report?type=found" class="btn btn-success">
                <i class="fas fa-plus-circle"></i>
                Report Found Item
              </a>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderTabs() {
    const tabs = [
      { id: 'overview', label: 'Overview', icon: 'tachometer-alt' },
      { id: 'items', label: 'My Items', icon: 'list' },
      { id: 'matches', label: 'Matches', icon: 'heart' },
      { id: 'messages', label: 'Messages', icon: 'envelope' },
      { id: 'analytics', label: 'Analytics', icon: 'chart-line' }
    ];

    return `
      <div class="dashboard-tabs">
        <div class="container">
          <div class="tab-list">
            ${tabs.map(tab => `
              <button 
                class="tab-button ${this.activeTab === tab.id ? 'active' : ''}"
                data-tab="${tab.id}"
              >
                <i class="fas fa-${tab.icon}"></i>
                <span>${tab.label}</span>
              </button>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  renderContent() {
    return `
      <div class="dashboard-content">
        <div class="container">
          <div class="tab-content" id="tabContent">
            ${this.renderTabContent()}
          </div>
        </div>
      </div>
    `;
  }

  renderTabContent() {
    switch (this.activeTab) {
      case 'overview':
        return this.renderOverviewTab();
      case 'items':
        return this.renderItemsTab();
      case 'matches':
        return this.renderMatchesTab();
      case 'messages':
        return this.renderMessagesTab();
      case 'analytics':
        return this.renderAnalyticsTab();
      default:
        return this.renderOverviewTab();
    }
  }

  renderOverviewTab() {
    return `
      <div class="overview-tab">
        <div class="stats-grid" id="statsGrid">
          <div class="stat-card">
            <div class="stat-icon">
              <i class="fas fa-list"></i>
            </div>
            <div class="stat-content">
              <div class="stat-number" id="totalItems">-</div>
              <div class="stat-label">Total Items</div>
              <div class="stat-change positive" id="itemsChange">+2 this week</div>
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-icon">
              <i class="fas fa-heart"></i>
            </div>
            <div class="stat-content">
              <div class="stat-number" id="totalMatches">-</div>
              <div class="stat-label">Potential Matches</div>
              <div class="stat-change positive" id="matchesChange">+1 new</div>
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-icon">
              <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-content">
              <div class="stat-number" id="recoveredItems">-</div>
              <div class="stat-label">Items Recovered</div>
              <div class="stat-change positive" id="recoveredChange">85% success rate</div>
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-icon">
              <i class="fas fa-envelope"></i>
            </div>
            <div class="stat-content">
              <div class="stat-number" id="unreadMessages">-</div>
              <div class="stat-label">Unread Messages</div>
              <div class="stat-change" id="messagesChange">View all</div>
            </div>
          </div>
        </div>
        
        <div class="dashboard-grid">
          <div class="dashboard-section">
            <div class="section-header">
              <h3>Recent Activity</h3>
              <a href="#" class="view-all-link">View All</a>
            </div>
            <div class="activity-list" id="recentActivity">
              <div class="loading-placeholder">
                <div class="spinner"></div>
                <p>Loading activity...</p>
              </div>
            </div>
          </div>
          
          <div class="dashboard-section">
            <div class="section-header">
              <h3>Quick Actions</h3>
            </div>
            <div class="quick-actions-grid">
              <a href="/report?type=lost" class="quick-action-card lost">
                <i class="fas fa-minus-circle"></i>
                <h4>Report Lost Item</h4>
                <p>Lost something? Report it here</p>
              </a>
              
              <a href="/report?type=found" class="quick-action-card found">
                <i class="fas fa-plus-circle"></i>
                <h4>Report Found Item</h4>
                <p>Found something? Help someone</p>
              </a>
              
              <a href="/search" class="quick-action-card search">
                <i class="fas fa-search"></i>
                <h4>Search Items</h4>
                <p>Browse lost and found items</p>
              </a>
              
              <a href="/messages" class="quick-action-card messages">
                <i class="fas fa-envelope"></i>
                <h4>View Messages</h4>
                <p>Check your conversations</p>
              </a>
            </div>
          </div>
        </div>
        
        <div class="dashboard-section">
          <div class="section-header">
            <h3>AI Insights</h3>
          </div>
          <div class="insights-grid" id="aiInsights">
            <div class="insight-card">
              <div class="insight-icon">
                <i class="fas fa-lightbulb"></i>
              </div>
              <div class="insight-content">
                <h4>Tip of the Day</h4>
                <p>Add more detailed descriptions to increase match accuracy by up to 40%</p>
              </div>
            </div>
            
            <div class="insight-card">
              <div class="insight-icon">
                <i class="fas fa-chart-line"></i>
              </div>
              <div class="insight-content">
                <h4>Recovery Trend</h4>
                <p>Items reported on weekdays have 25% higher recovery rates</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderItemsTab() {
    return `
      <div class="items-tab">
        <div class="items-header">
          <div class="items-filters">
            <select class="form-select" id="itemTypeFilter">
              <option value="">All Types</option>
              <option value="lost">Lost Items</option>
              <option value="found">Found Items</option>
            </select>
            
            <select class="form-select" id="itemStatusFilter">
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="recovered">Recovered</option>
              <option value="expired">Expired</option>
            </select>
            
            <input 
              type="text" 
              class="form-input" 
              id="itemSearchInput"
              placeholder="Search your items..."
            >
          </div>
          
          <div class="items-actions">
            <button class="btn btn-secondary" id="refreshItemsBtn">
              <i class="fas fa-sync-alt"></i>
              Refresh
            </button>
          </div>
        </div>
        
        <div class="items-grid" id="itemsGrid">
          <div class="loading-placeholder">
            <div class="spinner"></div>
            <p>Loading your items...</p>
          </div>
        </div>
        
        <div class="items-pagination" id="itemsPagination">
          <!-- Pagination will be rendered here -->
        </div>
      </div>
    `;
  }

  renderMatchesTab() {
    return `
      <div class="matches-tab">
        <div class="matches-header">
          <h3>Potential Matches</h3>
          <p>AI-powered matches for your items</p>
        </div>
        
        <div class="matches-filters">
          <select class="form-select" id="matchConfidenceFilter">
            <option value="">All Confidence Levels</option>
            <option value="high">High (80%+)</option>
            <option value="medium">Medium (60-79%)</option>
            <option value="low">Low (40-59%)</option>
          </select>
          
          <select class="form-select" id="matchStatusFilter">
            <option value="">All Status</option>
            <option value="pending">Pending Review</option>
            <option value="contacted">Contacted</option>
            <option value="confirmed">Confirmed</option>
            <option value="dismissed">Dismissed</option>
          </select>
        </div>
        
        <div class="matches-list" id="matchesList">
          <div class="loading-placeholder">
            <div class="spinner"></div>
            <p>Loading matches...</p>
          </div>
        </div>
      </div>
    `;
  }

  renderMessagesTab() {
    return `
      <div class="messages-tab">
        <div class="messages-layout">
          <div class="conversations-sidebar">
            <div class="conversations-header">
              <h3>Conversations</h3>
              <button class="btn btn-sm btn-primary" id="newMessageBtn">
                <i class="fas fa-plus"></i>
                New
              </button>
            </div>
            
            <div class="conversations-list" id="conversationsList">
              <div class="loading-placeholder">
                <div class="spinner"></div>
                <p>Loading conversations...</p>
              </div>
            </div>
          </div>
          
          <div class="message-area">
            <div class="message-placeholder">
              <i class="fas fa-envelope"></i>
              <h3>Select a conversation</h3>
              <p>Choose a conversation from the sidebar to start messaging</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderAnalyticsTab() {
    return `
      <div class="analytics-tab">
        <div class="analytics-header">
          <h3>Your Analytics</h3>
          <p>Insights about your lost and found activity</p>
        </div>
        
        <div class="analytics-grid">
          <div class="analytics-card">
            <div class="card-header">
              <h4>Recovery Rate</h4>
              <div class="chart-period">
                <select class="form-select" id="recoveryPeriod">
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                </select>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="recoveryChart"></canvas>
            </div>
          </div>
          
          <div class="analytics-card">
            <div class="card-header">
              <h4>Item Categories</h4>
            </div>
            <div class="chart-container">
              <canvas id="categoriesChart"></canvas>
            </div>
          </div>
          
          <div class="analytics-card">
            <div class="card-header">
              <h4>Match Accuracy</h4>
            </div>
            <div class="chart-container">
              <canvas id="accuracyChart"></canvas>
            </div>
          </div>
          
          <div class="analytics-card">
            <div class="card-header">
              <h4>Activity Timeline</h4>
            </div>
            <div class="chart-container">
              <canvas id="timelineChart"></canvas>
            </div>
          </div>
        </div>
        
        <div class="analytics-insights">
          <h4>Key Insights</h4>
          <div class="insights-list" id="analyticsInsights">
            <div class="loading-placeholder">
              <div class="spinner"></div>
              <p>Generating insights...</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  async onMount() {
    // Check authentication
    const authManager = window.LostFoundApp?.auth;
    if (!authManager?.isAuthenticated()) {
      this.router.navigate('/login?redirect=/dashboard');
      return;
    }

    this.setupEventListeners();
    await this.loadData();
    this.setupRealTimeUpdates();
  }

  setupEventListeners() {
    // Tab switching
    document.querySelectorAll('.tab-button').forEach(button => {
      button.addEventListener('click', (e) => {
        const tabId = e.currentTarget.dataset.tab;
        this.switchTab(tabId);
      });
    });

    // Refresh buttons
    const refreshBtn = document.getElementById('refreshItemsBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => this.refreshItems());
    }

    // Filters
    this.setupFilters();
  }

  setupFilters() {
    // Item filters
    const typeFilter = document.getElementById('itemTypeFilter');
    const statusFilter = document.getElementById('itemStatusFilter');
    const searchInput = document.getElementById('itemSearchInput');

    if (typeFilter) {
      typeFilter.addEventListener('change', () => this.filterItems());
    }
    if (statusFilter) {
      statusFilter.addEventListener('change', () => this.filterItems());
    }
    if (searchInput) {
      let searchTimeout;
      searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => this.filterItems(), 300);
      });
    }

    // Match filters
    const confidenceFilter = document.getElementById('matchConfidenceFilter');
    const matchStatusFilter = document.getElementById('matchStatusFilter');

    if (confidenceFilter) {
      confidenceFilter.addEventListener('change', () => this.filterMatches());
    }
    if (matchStatusFilter) {
      matchStatusFilter.addEventListener('change', () => this.filterMatches());
    }
  }

  async switchTab(tabId) {
    this.activeTab = tabId;
    
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('tab', tabId);
    history.replaceState(null, '', url);

    // Update active tab button
    document.querySelectorAll('.tab-button').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

    // Update content
    const tabContent = document.getElementById('tabContent');
    tabContent.innerHTML = this.renderTabContent();

    // Load tab-specific data
    await this.loadTabData(tabId);
  }

  async loadData() {
    try {
      // Load dashboard summary
      await this.loadDashboardSummary();
      
      // Load tab-specific data
      await this.loadTabData(this.activeTab);

    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      this.showError('Failed to load dashboard data');
    }
  }

  async loadDashboardSummary() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/dashboard/summary', { headers });
      
      if (response.ok) {
        this.data.summary = await response.json();
        this.updateSummaryStats();
      }
    } catch (error) {
      console.error('Failed to load dashboard summary:', error);
    }
  }

  async loadTabData(tabId) {
    switch (tabId) {
      case 'overview':
        await this.loadOverviewData();
        break;
      case 'items':
        await this.loadItemsData();
        break;
      case 'matches':
        await this.loadMatchesData();
        break;
      case 'messages':
        await this.loadMessagesData();
        break;
      case 'analytics':
        await this.loadAnalyticsData();
        break;
    }
  }

  async loadOverviewData() {
    try {
      // Load recent activity
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/dashboard/activity?limit=5', { headers });
      
      if (response.ok) {
        const activities = await response.json();
        this.renderRecentActivity(activities);
      }
    } catch (error) {
      console.error('Failed to load overview data:', error);
    }
  }

  async loadItemsData() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/items/my', { headers });
      
      if (response.ok) {
        this.data.items = await response.json();
        this.renderItemsGrid(this.data.items);
      }
    } catch (error) {
      console.error('Failed to load items data:', error);
      this.showItemsError();
    }
  }

  async loadMatchesData() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/matches/my', { headers });
      
      if (response.ok) {
        this.data.matches = await response.json();
        this.renderMatchesList(this.data.matches);
      }
    } catch (error) {
      console.error('Failed to load matches data:', error);
      this.showMatchesError();
    }
  }

  async loadMessagesData() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/messages/conversations', { headers });
      
      if (response.ok) {
        this.data.messages = await response.json();
        this.renderConversationsList(this.data.messages);
      }
    } catch (error) {
      console.error('Failed to load messages data:', error);
      this.showMessagesError();
    }
  }

  async loadAnalyticsData() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/analytics/personal', { headers });
      
      if (response.ok) {
        const analytics = await response.json();
        this.renderAnalyticsCharts(analytics);
      }
    } catch (error) {
      console.error('Failed to load analytics data:', error);
      this.showAnalyticsError();
    }
  }

  updateSummaryStats() {
    const summary = this.data.summary;
    
    this.updateElement('totalItems', summary.myItems || 0);
    this.updateElement('totalMatches', summary.matches || 0);
    this.updateElement('recoveredItems', summary.recoveredItems || 0);
    this.updateElement('unreadMessages', summary.unreadMessages || 0);
  }

  renderRecentActivity(activities) {
    const container = document.getElementById('recentActivity');
    
    if (!activities || activities.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-clock"></i>
          <p>No recent activity</p>
        </div>
      `;
      return;
    }

    container.innerHTML = activities.map(activity => `
      <div class="activity-item">
        <div class="activity-icon ${activity.type}">
          <i class="fas fa-${this.getActivityIcon(activity.type)}"></i>
        </div>
        <div class="activity-content">
          <div class="activity-text">${activity.description}</div>
          <div class="activity-time">${this.formatRelativeTime(activity.timestamp)}</div>
        </div>
      </div>
    `).join('');
  }

  renderItemsGrid(items) {
    const grid = document.getElementById('itemsGrid');
    
    if (!items || items.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-list"></i>
          <h3>No items found</h3>
          <p>You haven't reported any items yet</p>
          <a href="/report" class="btn btn-primary">Report Your First Item</a>
        </div>
      `;
      return;
    }

    grid.innerHTML = items.map(item => `
      <div class="item-card" onclick="window.LostFoundApp.router.navigate('/item/${item.id}')">
        <div class="item-header">
          <div class="item-type ${item.type}">${item.type}</div>
          <div class="item-status ${item.status}">${item.status}</div>
        </div>
        
        <div class="item-image">
          ${item.images && item.images.length > 0 ? 
            `<img src="${item.images[0]}" alt="${item.title}" loading="lazy">` :
            `<div class="item-placeholder">
              <i class="fas fa-${this.getItemIcon(item.category)}"></i>
            </div>`
          }
        </div>
        
        <div class="item-content">
          <h3 class="item-title">${item.title}</h3>
          <p class="item-description">${this.truncateText(item.description, 60)}</p>
          
          <div class="item-meta">
            <div class="item-location">
              <i class="fas fa-map-marker-alt"></i>
              ${item.location}
            </div>
            <div class="item-date">
              <i class="fas fa-clock"></i>
              ${this.formatRelativeTime(item.createdAt)}
            </div>
          </div>
          
          <div class="item-stats">
            <div class="stat">
              <i class="fas fa-eye"></i>
              ${item.views || 0} views
            </div>
            ${item.matchCount > 0 ? 
              `<div class="stat matches">
                <i class="fas fa-heart"></i>
                ${item.matchCount} matches
              </div>` : ''
            }
          </div>
        </div>
        
        <div class="item-actions">
          <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation(); editItem('${item.id}')">
            <i class="fas fa-edit"></i>
            Edit
          </button>
          <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); viewMatches('${item.id}')">
            <i class="fas fa-heart"></i>
            Matches
          </button>
        </div>
      </div>
    `).join('');
  }

  setupRealTimeUpdates() {
    // Setup Socket.IO for real-time updates
    if (window.io) {
      const socket = window.io();
      
      socket.on('new_match', (data) => {
        this.handleNewMatch(data);
      });
      
      socket.on('new_message', (data) => {
        this.handleNewMessage(data);
      });
      
      socket.on('item_status_update', (data) => {
        this.handleItemStatusUpdate(data);
      });
    }
  }

  handleNewMatch(data) {
    // Show notification
    if (window.LostFoundApp?.notifications) {
      window.LostFoundApp.notifications.showItemMatchNotification(data.item, data.match);
    }
    
    // Update matches count
    this.loadDashboardSummary();
    
    // Refresh matches tab if active
    if (this.activeTab === 'matches') {
      this.loadMatchesData();
    }
  }

  handleNewMessage(data) {
    // Update unread count
    this.loadDashboardSummary();
    
    // Refresh messages tab if active
    if (this.activeTab === 'messages') {
      this.loadMessagesData();
    }
  }

  handleItemStatusUpdate(data) {
    // Refresh items if active
    if (this.activeTab === 'items') {
      this.loadItemsData();
    }
  }

  // Utility methods
  updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  }

  formatRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    
    return date.toLocaleDateString();
  }

  truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  getItemIcon(category) {
    const icons = {
      electronics: 'mobile-alt',
      clothing: 'tshirt',
      accessories: 'ring',
      documents: 'file-alt',
      keys: 'key',
      bags: 'briefcase',
      books: 'book',
      sports: 'football-ball',
      jewelry: 'gem',
      other: 'question'
    };
    return icons[category] || 'question';
  }

  getActivityIcon(type) {
    const icons = {
      item_created: 'plus',
      match_found: 'heart',
      message_received: 'envelope',
      item_recovered: 'check-circle',
      item_expired: 'clock'
    };
    return icons[type] || 'info';
  }

  showError(message) {
    if (window.LostFoundApp?.showToast) {
      window.LostFoundApp.showToast(message, 'error');
    }
  }

  onUnmount() {
    // Cleanup socket connections
    if (this.socket) {
      this.socket.disconnect();
    }
  }
}

// Global functions for item actions
window.editItem = (itemId) => {
  window.LostFoundApp.router.navigate(`/item/${itemId}/edit`);
};

window.viewMatches = (itemId) => {
  window.LostFoundApp.router.navigate(`/item/${itemId}/matches`);
};