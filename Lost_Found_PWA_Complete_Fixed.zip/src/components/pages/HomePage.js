// Home Page for Lost & Found PWA
export default class HomePage {
  constructor({ params, query, router }) {
    this.params = params;
    this.query = query;
    this.router = router;
    this.title = 'Home';
    this.description = 'Smart Lost & Found system with AI matching and real-time notifications';
  }

  async render() {
    const authManager = window.LostFoundApp?.auth;
    const isAuthenticated = authManager?.isAuthenticated();
    const user = authManager?.getUser();

    const container = document.createElement('div');
    container.className = 'home-page';
    
    container.innerHTML = `
      ${this.renderNavbar(isAuthenticated, user)}
      ${this.renderHeroSection()}
      ${isAuthenticated ? this.renderDashboardPreview() : this.renderFeatures()}
      ${this.renderRecentItems()}
      ${this.renderStats()}
      ${this.renderFooter()}
    `;

    return container;
  }

  renderNavbar(isAuthenticated, user) {
    return `
      <nav class="navbar">
        <div class="container navbar-content">
          <a href="/" class="navbar-brand">
            <i class="fas fa-search"></i>
            Lost & Found
          </a>
          
          <ul class="navbar-nav">
            <li><a href="/search" class="navbar-link">Search</a></li>
            <li><a href="/report" class="navbar-link">Report Item</a></li>
            ${isAuthenticated ? `
              <li><a href="/dashboard" class="navbar-link">Dashboard</a></li>
              <li><a href="/messages" class="navbar-link">
                <i class="fas fa-envelope"></i>
                Messages
              </a></li>
              <li class="dropdown">
                <button class="navbar-link dropdown-toggle" id="userDropdown">
                  <img src="${user?.avatar || '/icons/default-avatar.png'}" 
                       alt="Avatar" class="avatar-sm">
                  ${user?.name || 'User'}
                </button>
                <div class="dropdown-menu" id="userDropdownMenu">
                  <a href="/profile" class="dropdown-item">Profile</a>
                  <a href="/settings" class="dropdown-item">Settings</a>
                  ${user?.role === 'admin' ? '<a href="/admin" class="dropdown-item">Admin</a>' : ''}
                  <div class="dropdown-divider"></div>
                  <button class="dropdown-item" id="logoutBtn">Logout</button>
                </div>
              </li>
            ` : `
              <li><a href="/login" class="btn btn-primary">Login</a></li>
            `}
          </ul>
        </div>
      </nav>
    `;
  }

  renderHeroSection() {
    const authManager = window.LostFoundApp?.auth;
    const isAuthenticated = authManager?.isAuthenticated();

    return `
      <section class="hero-section">
        <div class="container">
          <div class="hero-content">
            <div class="hero-text">
              <h1>Smart Lost & Found Recovery</h1>
              <p class="hero-subtitle">
                AI-powered matching, real-time notifications, and global reach. 
                Find your lost items faster than ever before.
              </p>
              
              <div class="hero-stats">
                <div class="stat-item">
                  <div class="stat-number">10,000+</div>
                  <div class="stat-label">Items Recovered</div>
                </div>
                <div class="stat-item">
                  <div class="stat-number">95%</div>
                  <div class="stat-label">Match Accuracy</div>
                </div>
                <div class="stat-item">
                  <div class="stat-number">24/7</div>
                  <div class="stat-label">AI Monitoring</div>
                </div>
              </div>
              
              <div class="hero-actions">
                ${isAuthenticated ? `
                  <a href="/report" class="btn btn-primary btn-lg">
                    <i class="fas fa-plus"></i>
                    Report Item
                  </a>
                  <a href="/search" class="btn btn-secondary btn-lg">
                    <i class="fas fa-search"></i>
                    Search Items
                  </a>
                ` : `
                  <a href="/register" class="btn btn-primary btn-lg">
                    <i class="fas fa-user-plus"></i>
                    Get Started
                  </a>
                  <a href="/search" class="btn btn-secondary btn-lg">
                    <i class="fas fa-search"></i>
                    Browse Items
                  </a>
                `}
              </div>
            </div>
            
            <div class="hero-image">
              <div class="hero-visual">
                <div class="floating-card lost-card">
                  <i class="fas fa-mobile-alt"></i>
                  <span>Lost Phone</span>
                </div>
                <div class="floating-card found-card">
                  <i class="fas fa-key"></i>
                  <span>Found Keys</span>
                </div>
                <div class="floating-card match-card">
                  <i class="fas fa-heart"></i>
                  <span>AI Match!</span>
                </div>
                <div class="ai-brain">
                  <i class="fas fa-brain"></i>
                  <div class="pulse-ring"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  renderDashboardPreview() {
    return `
      <section class="dashboard-preview">
        <div class="container">
          <h2>Your Dashboard</h2>
          <div class="dashboard-grid">
            <div class="dashboard-card" id="myItemsCard">
              <div class="card-icon">
                <i class="fas fa-list"></i>
              </div>
              <div class="card-content">
                <h3>My Items</h3>
                <p class="card-number" id="myItemsCount">Loading...</p>
                <p class="card-subtitle">Active listings</p>
              </div>
            </div>
            
            <div class="dashboard-card" id="matchesCard">
              <div class="card-icon">
                <i class="fas fa-heart"></i>
              </div>
              <div class="card-content">
                <h3>Matches</h3>
                <p class="card-number" id="matchesCount">Loading...</p>
                <p class="card-subtitle">Potential matches</p>
              </div>
            </div>
            
            <div class="dashboard-card" id="messagesCard">
              <div class="card-icon">
                <i class="fas fa-envelope"></i>
              </div>
              <div class="card-content">
                <h3>Messages</h3>
                <p class="card-number" id="messagesCount">Loading...</p>
                <p class="card-subtitle">Unread messages</p>
              </div>
            </div>
            
            <div class="dashboard-card" id="successCard">
              <div class="card-icon">
                <i class="fas fa-check-circle"></i>
              </div>
              <div class="card-content">
                <h3>Recovered</h3>
                <p class="card-number" id="successCount">Loading...</p>
                <p class="card-subtitle">Items recovered</p>
              </div>
            </div>
          </div>
          
          <div class="quick-actions">
            <a href="/report?type=lost" class="quick-action lost">
              <i class="fas fa-minus-circle"></i>
              <span>Report Lost Item</span>
            </a>
            <a href="/report?type=found" class="quick-action found">
              <i class="fas fa-plus-circle"></i>
              <span>Report Found Item</span>
            </a>
            <a href="/search" class="quick-action search">
              <i class="fas fa-search"></i>
              <span>Search Items</span>
            </a>
            <a href="/messages" class="quick-action messages">
              <i class="fas fa-envelope"></i>
              <span>View Messages</span>
            </a>
          </div>
        </div>
      </section>
    `;
  }

  renderFeatures() {
    return `
      <section class="features-section">
        <div class="container">
          <h2>Why Choose Our Platform?</h2>
          <div class="features-grid">
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-robot"></i>
              </div>
              <h3>AI-Powered Matching</h3>
              <p>Advanced machine learning algorithms analyze images and descriptions to find potential matches with 95% accuracy.</p>
            </div>
            
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-bell"></i>
              </div>
              <h3>Real-Time Notifications</h3>
              <p>Get instant alerts when potential matches are found. Never miss an opportunity to recover your items.</p>
            </div>
            
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-globe"></i>
              </div>
              <h3>Multi-Tenant Support</h3>
              <p>Works across universities, offices, transit systems, and communities. One platform, everywhere you go.</p>
            </div>
            
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-shield-alt"></i>
              </div>
              <h3>Privacy & Security</h3>
              <p>Your data is protected with enterprise-grade security. Control who sees your information.</p>
            </div>
            
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-mobile-alt"></i>
              </div>
              <h3>Offline Support</h3>
              <p>Report items even without internet. Data syncs automatically when connection is restored.</p>
            </div>
            
            <div class="feature-card">
              <div class="feature-icon">
                <i class="fas fa-chart-line"></i>
              </div>
              <h3>Analytics Dashboard</h3>
              <p>Track recovery rates, popular locations, and system performance with detailed analytics.</p>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  renderRecentItems() {
    return `
      <section class="recent-items-section">
        <div class="container">
          <div class="section-header">
            <h2>Recent Items</h2>
            <a href="/search" class="view-all-link">View All <i class="fas fa-arrow-right"></i></a>
          </div>
          
          <div class="items-grid" id="recentItemsGrid">
            <div class="loading-placeholder">
              <div class="spinner"></div>
              <p>Loading recent items...</p>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  renderStats() {
    return `
      <section class="stats-section">
        <div class="container">
          <h2>Platform Statistics</h2>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon">
                <i class="fas fa-users"></i>
              </div>
              <div class="stat-content">
                <div class="stat-number" id="totalUsers">25,000+</div>
                <div class="stat-label">Active Users</div>
              </div>
            </div>
            
            <div class="stat-card">
              <div class="stat-icon">
                <i class="fas fa-list"></i>
              </div>
              <div class="stat-content">
                <div class="stat-number" id="totalItems">50,000+</div>
                <div class="stat-label">Items Reported</div>
              </div>
            </div>
            
            <div class="stat-card">
              <div class="stat-icon">
                <i class="fas fa-handshake"></i>
              </div>
              <div class="stat-content">
                <div class="stat-number" id="successfulMatches">12,000+</div>
                <div class="stat-label">Successful Matches</div>
              </div>
            </div>
            
            <div class="stat-card">
              <div class="stat-icon">
                <i class="fas fa-clock"></i>
              </div>
              <div class="stat-content">
                <div class="stat-number" id="avgRecoveryTime">2.5 days</div>
                <div class="stat-label">Avg Recovery Time</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  renderFooter() {
    return `
      <footer class="footer">
        <div class="container">
          <div class="footer-content">
            <div class="footer-section">
              <h3>Lost & Found</h3>
              <p>Smart recovery system powered by AI and community collaboration.</p>
              <div class="social-links">
                <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                <a href="#" class="social-link"><i class="fab fa-github"></i></a>
              </div>
            </div>
            
            <div class="footer-section">
              <h4>Platform</h4>
              <ul class="footer-links">
                <li><a href="/search">Search Items</a></li>
                <li><a href="/report">Report Item</a></li>
                <li><a href="/help">How It Works</a></li>
                <li><a href="/analytics">Analytics</a></li>
              </ul>
            </div>
            
            <div class="footer-section">
              <h4>Support</h4>
              <ul class="footer-links">
                <li><a href="/help">Help Center</a></li>
                <li><a href="/contact">Contact Us</a></li>
                <li><a href="/privacy">Privacy Policy</a></li>
                <li><a href="/terms">Terms of Service</a></li>
              </ul>
            </div>
            
            <div class="footer-section">
              <h4>Stay Updated</h4>
              <p>Get notified about new features and updates.</p>
              <div class="newsletter-signup">
                <input type="email" placeholder="Enter your email" class="newsletter-input">
                <button class="newsletter-btn">Subscribe</button>
              </div>
            </div>
          </div>
          
          <div class="footer-bottom">
            <p>&copy; 2024 Lost & Found PWA. All rights reserved.</p>
            <p>Built with ❤️ for the community</p>
          </div>
        </div>
      </footer>
    `;
  }

  async onMount() {
    // Setup event listeners
    this.setupEventListeners();
    
    // Load data
    await this.loadData();
    
    // Setup animations
    this.setupAnimations();
  }

  setupEventListeners() {
    // User dropdown
    const userDropdown = document.getElementById('userDropdown');
    const userDropdownMenu = document.getElementById('userDropdownMenu');
    
    if (userDropdown && userDropdownMenu) {
      userDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdownMenu.classList.toggle('show');
      });
      
      document.addEventListener('click', () => {
        userDropdownMenu.classList.remove('show');
      });
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', async () => {
        const authManager = window.LostFoundApp?.auth;
        if (authManager) {
          await authManager.logout();
          this.router.navigate('/');
        }
      });
    }
    
    // Dashboard cards
    document.querySelectorAll('.dashboard-card').forEach(card => {
      card.addEventListener('click', () => {
        const cardId = card.id;
        switch (cardId) {
          case 'myItemsCard':
            this.router.navigate('/dashboard?tab=items');
            break;
          case 'matchesCard':
            this.router.navigate('/dashboard?tab=matches');
            break;
          case 'messagesCard':
            this.router.navigate('/messages');
            break;
          case 'successCard':
            this.router.navigate('/dashboard?tab=recovered');
            break;
        }
      });
    });
    
    // Newsletter signup
    const newsletterBtn = document.querySelector('.newsletter-btn');
    if (newsletterBtn) {
      newsletterBtn.addEventListener('click', () => {
        const email = document.querySelector('.newsletter-input').value;
        if (email) {
          this.subscribeToNewsletter(email);
        }
      });
    }
  }

  async loadData() {
    const authManager = window.LostFoundApp?.auth;
    
    if (authManager?.isAuthenticated()) {
      // Load dashboard data
      await this.loadDashboardData();
    }
    
    // Load recent items
    await this.loadRecentItems();
    
    // Load platform stats
    await this.loadPlatformStats();
  }

  async loadDashboardData() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager.getAuthHeaders();
      
      const response = await fetch('/api/dashboard/summary', { headers });
      
      if (response.ok) {
        const data = await response.json();
        
        // Update dashboard cards
        this.updateElement('myItemsCount', data.myItems || 0);
        this.updateElement('matchesCount', data.matches || 0);
        this.updateElement('messagesCount', data.unreadMessages || 0);
        this.updateElement('successCount', data.recoveredItems || 0);
      }
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  }

  async loadRecentItems() {
    try {
      const response = await fetch('/api/items/recent?limit=6');
      
      if (response.ok) {
        const items = await response.json();
        this.renderRecentItemsGrid(items);
      }
    } catch (error) {
      console.error('Failed to load recent items:', error);
      this.showRecentItemsError();
    }
  }

  async loadPlatformStats() {
    try {
      const response = await fetch('/api/stats/platform');
      
      if (response.ok) {
        const stats = await response.json();
        
        this.updateElement('totalUsers', this.formatNumber(stats.totalUsers));
        this.updateElement('totalItems', this.formatNumber(stats.totalItems));
        this.updateElement('successfulMatches', this.formatNumber(stats.successfulMatches));
        this.updateElement('avgRecoveryTime', stats.avgRecoveryTime);
      }
    } catch (error) {
      console.error('Failed to load platform stats:', error);
    }
  }

  renderRecentItemsGrid(items) {
    const grid = document.getElementById('recentItemsGrid');
    
    if (items.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-search"></i>
          <h3>No recent items</h3>
          <p>Be the first to report an item!</p>
          <a href="/report" class="btn btn-primary">Report Item</a>
        </div>
      `;
      return;
    }
    
    grid.innerHTML = items.map(item => `
      <div class="item-card" onclick="window.LostFoundApp.router.navigate('/item/${item.id}')">
        <div class="item-image">
          ${item.images && item.images.length > 0 ? 
            `<img src="${item.images[0]}" alt="${item.title}" loading="lazy">` :
            `<div class="item-placeholder">
              <i class="fas fa-${this.getItemIcon(item.category)}"></i>
            </div>`
          }
          <div class="item-type ${item.type}">${item.type}</div>
        </div>
        
        <div class="item-content">
          <h3 class="item-title">${item.title}</h3>
          <p class="item-description">${this.truncateText(item.description, 80)}</p>
          
          <div class="item-meta">
            <div class="item-location">
              <i class="fas fa-map-marker-alt"></i>
              ${item.location}
            </div>
            <div class="item-date">
              <i class="fas fa-clock"></i>
              ${this.formatRelativeTime(item.createdAt)}
            </div>
          </div>
          
          <div class="item-footer">
            <div class="item-category">
              <i class="fas fa-tag"></i>
              ${item.category}
            </div>
            ${item.matchCount > 0 ? 
              `<div class="item-matches">
                <i class="fas fa-heart"></i>
                ${item.matchCount} matches
              </div>` : ''
            }
          </div>
        </div>
      </div>
    `).join('');
  }

  showRecentItemsError() {
    const grid = document.getElementById('recentItemsGrid');
    grid.innerHTML = `
      <div class="error-state">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>Failed to load items</h3>
        <p>Please check your connection and try again.</p>
        <button class="btn btn-secondary" onclick="location.reload()">Retry</button>
      </div>
    `;
  }

  setupAnimations() {
    // Animate hero stats on scroll
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.stat-item, .feature-card, .stat-card').forEach(el => {
      observer.observe(el);
    });
    
    // Floating cards animation
    this.animateFloatingCards();
  }

  animateFloatingCards() {
    const cards = document.querySelectorAll('.floating-card');
    cards.forEach((card, index) => {
      card.style.animationDelay = `${index * 0.5}s`;
      card.classList.add('floating');
    });
  }

  async subscribeToNewsletter(email) {
    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      
      if (response.ok) {
        this.showToast('Successfully subscribed to newsletter!', 'success');
        document.querySelector('.newsletter-input').value = '';
      } else {
        this.showToast('Failed to subscribe. Please try again.', 'error');
      }
    } catch (error) {
      this.showToast('Network error. Please try again.', 'error');
    }
  }

  // Utility methods
  updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  }

  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  formatRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    
    return date.toLocaleDateString();
  }

  truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  getItemIcon(category) {
    const icons = {
      electronics: 'mobile-alt',
      clothing: 'tshirt',
      accessories: 'ring',
      documents: 'file-alt',
      keys: 'key',
      bags: 'briefcase',
      books: 'book',
      sports: 'football-ball',
      jewelry: 'gem',
      other: 'question'
    };
    return icons[category] || 'question';
  }

  showToast(message, type) {
    if (window.LostFoundApp?.showToast) {
      window.LostFoundApp.showToast(message, type);
    }
  }

  onUnmount() {
    // Cleanup event listeners and observers
  }
}