// Login Page for Lost & Found PWA
export default class LoginPage {
  constructor({ params, query, router }) {
    this.params = params;
    this.query = query;
    this.router = router;
    this.title = 'Login';
    this.description = 'Sign in to your Lost & Found account';
    this.isLoading = false;
  }

  async render() {
    const container = document.createElement('div');
    container.className = 'login-page';
    
    container.innerHTML = `
      <div class="auth-container">
        <div class="auth-card">
          <div class="auth-header">
            <a href="/" class="auth-logo">
              <i class="fas fa-search"></i>
              Lost & Found
            </a>
            <h1>Welcome Back</h1>
            <p>Sign in to access your account and manage your items</p>
          </div>
          
          <form class="auth-form" id="loginForm">
            <div class="form-group">
              <label for="email" class="form-label">Email Address</label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                class="form-input" 
                placeholder="Enter your email"
                required
                autocomplete="email"
              >
            </div>
            
            <div class="form-group">
              <label for="password" class="form-label">Password</label>
              <div class="password-input-group">
                <input 
                  type="password" 
                  id="password" 
                  name="password" 
                  class="form-input" 
                  placeholder="Enter your password"
                  required
                  autocomplete="current-password"
                >
                <button type="button" class="password-toggle" id="passwordToggle">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="form-options">
              <label class="checkbox-label">
                <input type="checkbox" id="rememberMe" name="rememberMe">
                <span class="checkmark"></span>
                Remember me
              </label>
              
              <a href="/forgot-password" class="forgot-link">Forgot password?</a>
            </div>
            
            <button type="submit" class="btn btn-primary btn-lg w-full" id="loginBtn">
              <span class="btn-text">Sign In</span>
              <div class="btn-loading hidden">
                <div class="spinner"></div>
                Signing in...
              </div>
            </button>
            
            <div class="auth-divider">
              <span>or</span>
            </div>
            
            <button type="button" class="btn btn-secondary btn-lg w-full" id="googleLoginBtn">
              <i class="fab fa-google"></i>
              Continue with Google
            </button>
            
            <button type="button" class="btn btn-secondary btn-lg w-full" id="guestLoginBtn">
              <i class="fas fa-user"></i>
              Continue as Guest
            </button>
          </form>
          
          <div class="auth-footer">
            <p>Don't have an account? <a href="/register">Sign up here</a></p>
          </div>
        </div>
        
        <div class="auth-features">
          <h3>Why Join Lost & Found?</h3>
          <div class="feature-list">
            <div class="feature-item">
              <i class="fas fa-robot"></i>
              <div>
                <h4>AI-Powered Matching</h4>
                <p>Get notified instantly when potential matches are found</p>
              </div>
            </div>
            
            <div class="feature-item">
              <i class="fas fa-bell"></i>
              <div>
                <h4>Real-Time Alerts</h4>
                <p>Receive push notifications for important updates</p>
              </div>
            </div>
            
            <div class="feature-item">
              <i class="fas fa-shield-alt"></i>
              <div>
                <h4>Secure & Private</h4>
                <p>Your personal information is always protected</p>
              </div>
            </div>
            
            <div class="feature-item">
              <i class="fas fa-mobile-alt"></i>
              <div>
                <h4>Works Offline</h4>
                <p>Report items even without internet connection</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    return container;
  }

  async onMount() {
    // Check if already authenticated
    const authManager = window.LostFoundApp?.auth;
    if (authManager?.isAuthenticated()) {
      this.router.navigate('/dashboard');
      return;
    }

    this.setupEventListeners();
    this.setupFormValidation();
    
    // Pre-fill email if provided in query params
    if (this.query.email) {
      document.getElementById('email').value = this.query.email;
    }
  }

  setupEventListeners() {
    // Login form submission
    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', (e) => this.handleLogin(e));

    // Password toggle
    const passwordToggle = document.getElementById('passwordToggle');
    passwordToggle.addEventListener('click', () => this.togglePassword());

    // Google login
    const googleLoginBtn = document.getElementById('googleLoginBtn');
    googleLoginBtn.addEventListener('click', () => this.handleGoogleLogin());

    // Guest login
    const guestLoginBtn = document.getElementById('guestLoginBtn');
    guestLoginBtn.addEventListener('click', () => this.handleGuestLogin());

    // Real-time validation
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    
    emailInput.addEventListener('blur', () => this.validateEmail());
    passwordInput.addEventListener('input', () => this.validatePassword());
  }

  setupFormValidation() {
    const form = document.getElementById('loginForm');
    const inputs = form.querySelectorAll('input[required]');
    
    inputs.forEach(input => {
      input.addEventListener('invalid', (e) => {
        e.preventDefault();
        this.showFieldError(input, this.getValidationMessage(input));
      });
      
      input.addEventListener('input', () => {
        this.clearFieldError(input);
      });
    });
  }

  async handleLogin(event) {
    event.preventDefault();
    
    if (this.isLoading) return;
    
    const formData = new FormData(event.target);
    const credentials = {
      email: formData.get('email'),
      password: formData.get('password')
    };

    // Validate form
    if (!this.validateForm(credentials)) {
      return;
    }

    this.setLoading(true);

    try {
      const authManager = window.LostFoundApp?.auth;
      if (!authManager) {
        throw new Error('Authentication manager not available');
      }

      const result = await authManager.login(credentials);

      if (result.success) {
        // Track successful login
        if (window.LostFoundApp?.analytics) {
          window.LostFoundApp.analytics.track('user_login', {
            method: 'email',
            timestamp: new Date().toISOString()
          });
        }

        this.showSuccess('Login successful! Redirecting...');
        
        // Redirect to intended page or dashboard
        const redirectTo = this.query.redirect || '/dashboard';
        setTimeout(() => {
          this.router.navigate(redirectTo);
        }, 1000);

      } else {
        this.showError(result.error || 'Login failed. Please try again.');
      }

    } catch (error) {
      console.error('Login error:', error);
      this.showError('Network error. Please check your connection and try again.');
    } finally {
      this.setLoading(false);
    }
  }

  async handleGoogleLogin() {
    try {
      const authManager = window.LostFoundApp?.auth;
      if (!authManager) {
        throw new Error('Authentication manager not available');
      }

      this.showInfo('Opening Google authentication...');
      
      const result = await authManager.googleLogin();

      if (result.success) {
        // Track successful login
        if (window.LostFoundApp?.analytics) {
          window.LostFoundApp.analytics.track('user_login', {
            method: 'google',
            timestamp: new Date().toISOString()
          });
        }

        this.showSuccess('Google login successful! Redirecting...');
        
        const redirectTo = this.query.redirect || '/dashboard';
        setTimeout(() => {
          this.router.navigate(redirectTo);
        }, 1000);

      } else {
        this.showError(result.error || 'Google login failed. Please try again.');
      }

    } catch (error) {
      console.error('Google login error:', error);
      this.showError('Google authentication failed. Please try again.');
    }
  }

  async handleGuestLogin() {
    try {
      const authManager = window.LostFoundApp?.auth;
      if (!authManager) {
        throw new Error('Authentication manager not available');
      }

      this.showInfo('Setting up guest access...');
      
      const result = await authManager.enableGuestMode();

      if (result.success) {
        // Track guest login
        if (window.LostFoundApp?.analytics) {
          window.LostFoundApp.analytics.track('user_login', {
            method: 'guest',
            timestamp: new Date().toISOString()
          });
        }

        this.showSuccess('Guest access enabled! Redirecting...');
        
        setTimeout(() => {
          this.router.navigate('/');
        }, 1000);

      } else {
        this.showError('Failed to enable guest access. Please try again.');
      }

    } catch (error) {
      console.error('Guest login error:', error);
      this.showError('Failed to enable guest access. Please try again.');
    }
  }

  togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.querySelector('#passwordToggle i');
    
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      toggleIcon.className = 'fas fa-eye-slash';
    } else {
      passwordInput.type = 'password';
      toggleIcon.className = 'fas fa-eye';
    }
  }

  validateForm(credentials) {
    let isValid = true;

    // Email validation
    if (!credentials.email) {
      this.showFieldError(document.getElementById('email'), 'Email is required');
      isValid = false;
    } else if (!this.isValidEmail(credentials.email)) {
      this.showFieldError(document.getElementById('email'), 'Please enter a valid email address');
      isValid = false;
    }

    // Password validation
    if (!credentials.password) {
      this.showFieldError(document.getElementById('password'), 'Password is required');
      isValid = false;
    } else if (credentials.password.length < 6) {
      this.showFieldError(document.getElementById('password'), 'Password must be at least 6 characters');
      isValid = false;
    }

    return isValid;
  }

  validateEmail() {
    const emailInput = document.getElementById('email');
    const email = emailInput.value.trim();
    
    if (email && !this.isValidEmail(email)) {
      this.showFieldError(emailInput, 'Please enter a valid email address');
      return false;
    }
    
    this.clearFieldError(emailInput);
    return true;
  }

  validatePassword() {
    const passwordInput = document.getElementById('password');
    const password = passwordInput.value;
    
    if (password && password.length < 6) {
      this.showFieldError(passwordInput, 'Password must be at least 6 characters');
      return false;
    }
    
    this.clearFieldError(passwordInput);
    return true;
  }

  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  showFieldError(input, message) {
    this.clearFieldError(input);
    
    input.classList.add('error');
    
    const errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    
    input.parentNode.appendChild(errorElement);
  }

  clearFieldError(input) {
    input.classList.remove('error');
    
    const existingError = input.parentNode.querySelector('.field-error');
    if (existingError) {
      existingError.remove();
    }
  }

  getValidationMessage(input) {
    if (input.validity.valueMissing) {
      return `${input.name} is required`;
    }
    if (input.validity.typeMismatch) {
      return `Please enter a valid ${input.type}`;
    }
    if (input.validity.tooShort) {
      return `${input.name} must be at least ${input.minLength} characters`;
    }
    return 'Please check this field';
  }

  setLoading(loading) {
    this.isLoading = loading;
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnLoading = loginBtn.querySelector('.btn-loading');
    
    if (loading) {
      loginBtn.disabled = true;
      btnText.classList.add('hidden');
      btnLoading.classList.remove('hidden');
    } else {
      loginBtn.disabled = false;
      btnText.classList.remove('hidden');
      btnLoading.classList.add('hidden');
    }
  }

  showSuccess(message) {
    this.showMessage(message, 'success');
  }

  showError(message) {
    this.showMessage(message, 'error');
  }

  showInfo(message) {
    this.showMessage(message, 'info');
  }

  showMessage(message, type) {
    // Remove existing messages
    const existingMessage = document.querySelector('.auth-message');
    if (existingMessage) {
      existingMessage.remove();
    }

    // Create new message
    const messageElement = document.createElement('div');
    messageElement.className = `auth-message auth-message-${type}`;
    messageElement.innerHTML = `
      <i class="fas fa-${this.getMessageIcon(type)}"></i>
      <span>${message}</span>
    `;

    // Insert after form header
    const authHeader = document.querySelector('.auth-header');
    authHeader.insertAdjacentElement('afterend', messageElement);

    // Auto-remove success/info messages
    if (type === 'success' || type === 'info') {
      setTimeout(() => {
        if (messageElement.parentNode) {
          messageElement.remove();
        }
      }, 5000);
    }
  }

  getMessageIcon(type) {
    const icons = {
      success: 'check-circle',
      error: 'exclamation-circle',
      info: 'info-circle',
      warning: 'exclamation-triangle'
    };
    return icons[type] || 'info-circle';
  }

  onUnmount() {
    // Cleanup if needed
  }
}