// Main application entry point
import './styles/main.css';
import { AppRouter } from './components/AppRouter.js';
import { AuthManager } from './utils/AuthManager.js';
import { NotificationManager } from './utils/NotificationManager.js';
import { OfflineManager } from './utils/OfflineManager.js';
import { AnalyticsManager } from './utils/AnalyticsManager.js';

class LostFoundApp {
  constructor() {
    this.router = new AppRouter();
    this.auth = new AuthManager();
    this.notifications = new NotificationManager();
    this.offline = new OfflineManager();
    this.analytics = new AnalyticsManager();
    
    this.init();
  }

  async init() {
    console.log('🚀 Initializing Lost & Found PWA...');
    
    try {
      // Initialize core managers
      await this.initializeManagers();
      
      // Setup event listeners
      this.setupEventListeners();
      
      // Initialize router
      await this.router.init();
      
      // Check authentication state
      await this.auth.checkAuthState();
      
      // Setup PWA features
      this.setupPWAFeatures();
      
      console.log('✅ App initialized successfully');
      
      // Track app initialization
      this.analytics.track('app_initialized', {
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        online: navigator.onLine
      });
      
    } catch (error) {
      console.error('❌ Failed to initialize app:', error);
      this.showErrorMessage('Failed to initialize application. Please refresh the page.');
    }
  }

  async initializeManagers() {
    // Initialize authentication
    await this.auth.init();
    
    // Initialize notifications
    await this.notifications.init();
    
    // Initialize offline functionality
    await this.offline.init();
    
    // Initialize analytics
    await this.analytics.init();
  }

  setupEventListeners() {
    // Online/offline status
    window.addEventListener('online', () => {
      console.log('📶 Connection restored');
      this.showToast('Connection restored', 'success');
      this.offline.syncOfflineData();
    });

    window.addEventListener('offline', () => {
      console.log('📵 Connection lost');
      this.showToast('You are now offline. Some features may be limited.', 'warning');
    });

    // App visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.analytics.track('app_focus');
        this.notifications.checkForUpdates();
      } else {
        this.analytics.track('app_blur');
      }
    });

    // Unhandled errors
    window.addEventListener('error', (event) => {
      console.error('Global error:', event.error);
      this.analytics.track('error', {
        message: event.error.message,
        stack: event.error.stack,
        filename: event.filename,
        lineno: event.lineno
      });
    });

    // Unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      console.error('Unhandled promise rejection:', event.reason);
      this.analytics.track('promise_rejection', {
        reason: event.reason.toString()
      });
    });
  }

  setupPWAFeatures() {
    // Install prompt handling
    let deferredPrompt;
    
    window.addEventListener('beforeinstallprompt', (e) => {
      console.log('💾 Install prompt available');
      e.preventDefault();
      deferredPrompt = e;
      this.showInstallPrompt(deferredPrompt);
    });

    // App installed
    window.addEventListener('appinstalled', () => {
      console.log('📱 App installed');
      this.analytics.track('app_installed');
      this.showToast('App installed successfully!', 'success');
    });

    // Check for app updates
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        console.log('🔄 App updated');
        this.showUpdatePrompt();
      });
    }
  }

  showInstallPrompt(deferredPrompt) {
    const installBanner = document.createElement('div');
    installBanner.className = 'install-banner';
    installBanner.innerHTML = `
      <div class="install-content">
        <i class="fas fa-download"></i>
        <span>Install Lost & Found for quick access</span>
        <button class="install-btn" id="installBtn">Install</button>
        <button class="close-btn" id="closeInstall">&times;</button>
      </div>
    `;
    
    document.body.appendChild(installBanner);
    
    document.getElementById('installBtn').addEventListener('click', async () => {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      
      this.analytics.track('install_prompt_result', { outcome });
      
      if (outcome === 'accepted') {
        console.log('User accepted install prompt');
      } else {
        console.log('User dismissed install prompt');
      }
      
      installBanner.remove();
      deferredPrompt = null;
    });
    
    document.getElementById('closeInstall').addEventListener('click', () => {
      installBanner.remove();
      this.analytics.track('install_prompt_dismissed');
    });
  }

  showUpdatePrompt() {
    const updateBanner = document.createElement('div');
    updateBanner.className = 'update-banner';
    updateBanner.innerHTML = `
      <div class="update-content">
        <i class="fas fa-sync-alt"></i>
        <span>A new version is available</span>
        <button class="update-btn" id="updateBtn">Refresh</button>
        <button class="close-btn" id="closeUpdate">&times;</button>
      </div>
    `;
    
    document.body.appendChild(updateBanner);
    
    document.getElementById('updateBtn').addEventListener('click', () => {
      window.location.reload();
    });
    
    document.getElementById('closeUpdate').addEventListener('click', () => {
      updateBanner.remove();
    });
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-content">
        <i class="fas fa-${this.getToastIcon(type)}"></i>
        <span>${message}</span>
      </div>
    `;
    
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Remove after delay
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  getToastIcon(type) {
    const icons = {
      success: 'check-circle',
      error: 'exclamation-circle',
      warning: 'exclamation-triangle',
      info: 'info-circle'
    };
    return icons[type] || 'info-circle';
  }

  showErrorMessage(message) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'error-container';
    errorContainer.innerHTML = `
      <div class="error-content">
        <i class="fas fa-exclamation-triangle"></i>
        <h2>Something went wrong</h2>
        <p>${message}</p>
        <button class="retry-btn" onclick="window.location.reload()">
          <i class="fas fa-redo"></i> Retry
        </button>
      </div>
    `;
    
    document.getElementById('app').innerHTML = '';
    document.getElementById('app').appendChild(errorContainer);
  }
}

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new LostFoundApp();
  });
} else {
  new LostFoundApp();
}

// Export for global access
window.LostFoundApp = LostFoundApp;