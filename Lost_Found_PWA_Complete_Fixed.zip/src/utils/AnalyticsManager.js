// Analytics Manager for Lost & Found PWA
export class AnalyticsManager {
  constructor() {
    this.isEnabled = true;
    this.sessionId = this.generateSessionId();
    this.userId = null;
    this.events = [];
    this.batchSize = 10;
    this.flushInterval = 30000; // 30 seconds
    this.maxRetries = 3;
    this.retryDelay = 5000; // 5 seconds
    this.isOnline = navigator.onLine;
    this.costMetrics = new Map();
    this.performanceMetrics = new Map();
    this.userJourney = [];
    this.startTime = Date.now();
  }

  async init() {
    console.log('📊 Initializing AnalyticsManager...');
    
    try {
      // Load user preferences
      await this.loadPreferences();
      
      // Setup event listeners
      this.setupEventListeners();
      
      // Start periodic flush
      this.startPeriodicFlush();
      
      // Track session start
      this.track('session_start', {
        sessionId: this.sessionId,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        screen: {
          width: screen.width,
          height: screen.height,
          colorDepth: screen.colorDepth
        },
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight
        },
        connection: this.getConnectionInfo(),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      });
      
      console.log('✅ AnalyticsManager initialized');
      
    } catch (error) {
      console.error('❌ AnalyticsManager initialization failed:', error);
    }
  }

  async loadPreferences() {
    try {
      const offlineManager = window.LostFoundApp?.offline;
      if (offlineManager) {
        this.isEnabled = await offlineManager.getPreference('analytics_enabled', true);
      }
    } catch (error) {
      console.error('Failed to load analytics preferences:', error);
    }
  }

  setupEventListeners() {
    // Network status
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.track('network_online');
      this.flushEvents();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      this.track('network_offline');
    });

    // Page visibility
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.track('page_visible');
      } else {
        this.track('page_hidden');
        this.flushEvents(); // Flush before page becomes hidden
      }
    });

    // Performance monitoring
    window.addEventListener('load', () => {
      this.trackPerformance();
    });

    // Error tracking
    window.addEventListener('error', (event) => {
      this.trackError('javascript_error', {
        message: event.error?.message || event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack
      });
    });

    window.addEventListener('unhandledrejection', (event) => {
      this.trackError('unhandled_promise_rejection', {
        reason: event.reason?.toString() || 'Unknown reason'
      });
    });

    // User interaction tracking
    document.addEventListener('click', (event) => {
      this.trackUserInteraction('click', event);
    });

    // Form submissions
    document.addEventListener('submit', (event) => {
      this.trackFormSubmission(event);
    });
  }

  // Core tracking methods
  track(eventName, properties = {}) {
    if (!this.isEnabled) return;

    const event = {
      id: this.generateEventId(),
      name: eventName,
      properties: {
        ...properties,
        sessionId: this.sessionId,
        userId: this.userId,
        timestamp: new Date().toISOString(),
        url: window.location.href,
        referrer: document.referrer,
        userAgent: navigator.userAgent
      },
      context: this.getContext()
    };

    // Add to events array
    this.events.push(event);

    // Add to user journey
    this.userJourney.push({
      event: eventName,
      timestamp: event.properties.timestamp,
      url: window.location.href
    });

    // Limit user journey size
    if (this.userJourney.length > 100) {
      this.userJourney.shift();
    }

    console.log('📊 Analytics event:', eventName, properties);

    // Auto-flush if batch size reached
    if (this.events.length >= this.batchSize) {
      this.flushEvents();
    }
  }

  trackPageView(path, title) {
    this.track('page_view', {
      path,
      title,
      loadTime: Date.now() - this.startTime
    });
  }

  trackUserAction(action, target, properties = {}) {
    this.track('user_action', {
      action,
      target,
      ...properties
    });
  }

  trackError(type, errorData) {
    this.track('error', {
      type,
      ...errorData,
      severity: this.calculateErrorSeverity(type, errorData)
    });
  }

  trackPerformance() {
    if (!window.performance) return;

    const navigation = performance.getEntriesByType('navigation')[0];
    const paint = performance.getEntriesByType('paint');

    const performanceData = {
      loadTime: navigation?.loadEventEnd - navigation?.loadEventStart,
      domContentLoaded: navigation?.domContentLoadedEventEnd - navigation?.domContentLoadedEventStart,
      firstPaint: paint.find(p => p.name === 'first-paint')?.startTime,
      firstContentfulPaint: paint.find(p => p.name === 'first-contentful-paint')?.startTime,
      transferSize: navigation?.transferSize,
      encodedBodySize: navigation?.encodedBodySize,
      decodedBodySize: navigation?.decodedBodySize
    };

    this.track('performance', performanceData);
  }

  trackUserInteraction(type, event) {
    const target = event.target;
    const tagName = target.tagName.toLowerCase();
    
    // Only track meaningful interactions
    if (['button', 'a', 'input', 'select', 'textarea'].includes(tagName)) {
      this.track('user_interaction', {
        type,
        element: tagName,
        id: target.id,
        className: target.className,
        text: target.textContent?.slice(0, 100) || '',
        href: target.href,
        coordinates: {
          x: event.clientX,
          y: event.clientY
        }
      });
    }
  }

  trackFormSubmission(event) {
    const form = event.target;
    const formData = new FormData(form);
    const fields = [];

    for (const [name, value] of formData.entries()) {
      fields.push({
        name,
        type: form.elements[name]?.type || 'unknown',
        hasValue: !!value,
        valueLength: value.toString().length
      });
    }

    this.track('form_submission', {
      formId: form.id,
      formAction: form.action,
      formMethod: form.method,
      fieldCount: fields.length,
      fields
    });
  }

  // Cost analytics tracking
  trackCostEvent(eventType, costData) {
    const costEvent = {
      type: eventType,
      ...costData,
      timestamp: new Date().toISOString()
    };

    // Store in cost metrics
    const key = `${eventType}_${Date.now()}`;
    this.costMetrics.set(key, costEvent);

    // Track as regular analytics event
    this.track('cost_event', costEvent);

    // Limit cost metrics size
    if (this.costMetrics.size > 1000) {
      const oldestKey = this.costMetrics.keys().next().value;
      this.costMetrics.delete(oldestKey);
    }
  }

  trackResourceUsage(resource, usage) {
    this.track('resource_usage', {
      resource,
      usage,
      timestamp: new Date().toISOString()
    });
  }

  trackAPICall(endpoint, method, duration, status, error = null) {
    this.track('api_call', {
      endpoint,
      method,
      duration,
      status,
      error: error ? {
        message: error.message,
        type: error.constructor.name
      } : null
    });
  }

  // Business metrics
  trackItemAction(action, itemData) {
    this.track('item_action', {
      action, // 'create', 'update', 'delete', 'view', 'search'
      itemId: itemData.id,
      category: itemData.category,
      type: itemData.type, // 'lost' or 'found'
      ...itemData
    });
  }

  trackSearchQuery(query, filters, resultCount, duration) {
    this.track('search', {
      query,
      filters,
      resultCount,
      duration,
      hasResults: resultCount > 0
    });
  }

  trackMatchFound(lostItemId, foundItemId, confidence, method) {
    this.track('match_found', {
      lostItemId,
      foundItemId,
      confidence,
      method, // 'ai', 'manual', 'keyword'
      timestamp: new Date().toISOString()
    });
  }

  trackUserEngagement(action, duration = null) {
    this.track('user_engagement', {
      action,
      duration,
      sessionDuration: Date.now() - this.startTime
    });
  }

  // Event flushing
  async flushEvents() {
    if (this.events.length === 0 || !this.isOnline) return;

    const eventsToSend = [...this.events];
    this.events = [];

    try {
      await this.sendEvents(eventsToSend);
      console.log(`📤 Sent ${eventsToSend.length} analytics events`);
    } catch (error) {
      console.error('Failed to send analytics events:', error);
      
      // Re-add events to queue for retry
      this.events.unshift(...eventsToSend);
      
      // Limit queue size to prevent memory issues
      if (this.events.length > 1000) {
        this.events = this.events.slice(-1000);
      }
    }
  }

  async sendEvents(events, retryCount = 0) {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = {
        'Content-Type': 'application/json',
        ...authManager?.getAuthHeaders()
      };

      const response = await fetch('/api/analytics/events', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          events,
          sessionId: this.sessionId,
          batchId: this.generateEventId()
        })
      });

      if (!response.ok) {
        throw new Error(`Analytics API error: ${response.status}`);
      }

      return await response.json();
      
    } catch (error) {
      if (retryCount < this.maxRetries) {
        console.log(`Retrying analytics send (${retryCount + 1}/${this.maxRetries})`);
        await this.delay(this.retryDelay * Math.pow(2, retryCount));
        return this.sendEvents(events, retryCount + 1);
      } else {
        throw error;
      }
    }
  }

  startPeriodicFlush() {
    setInterval(() => {
      this.flushEvents();
    }, this.flushInterval);

    // Flush on page unload
    window.addEventListener('beforeunload', () => {
      this.flushEvents();
    });
  }

  // Utility methods
  generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  generateEventId() {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  getContext() {
    return {
      page: {
        url: window.location.href,
        title: document.title,
        referrer: document.referrer
      },
      screen: {
        width: screen.width,
        height: screen.height
      },
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      connection: this.getConnectionInfo(),
      performance: this.getPerformanceInfo()
    };
  }

  getConnectionInfo() {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    
    if (connection) {
      return {
        effectiveType: connection.effectiveType,
        downlink: connection.downlink,
        rtt: connection.rtt,
        saveData: connection.saveData
      };
    }
    
    return { type: 'unknown' };
  }

  getPerformanceInfo() {
    if (!window.performance) return {};
    
    return {
      memory: performance.memory ? {
        usedJSHeapSize: performance.memory.usedJSHeapSize,
        totalJSHeapSize: performance.memory.totalJSHeapSize,
        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
      } : undefined,
      timing: performance.timing ? {
        navigationStart: performance.timing.navigationStart,
        loadEventEnd: performance.timing.loadEventEnd
      } : undefined
    };
  }

  calculateErrorSeverity(type, errorData) {
    // Simple severity calculation
    if (type === 'javascript_error') {
      if (errorData.message?.includes('Network') || errorData.message?.includes('fetch')) {
        return 'low';
      }
      if (errorData.message?.includes('TypeError') || errorData.message?.includes('ReferenceError')) {
        return 'high';
      }
      return 'medium';
    }
    
    if (type === 'unhandled_promise_rejection') {
      return 'medium';
    }
    
    return 'low';
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Public API
  setUserId(userId) {
    this.userId = userId;
    this.track('user_identified', { userId });
  }

  setUserProperties(properties) {
    this.track('user_properties_updated', properties);
  }

  enable() {
    this.isEnabled = true;
    this.track('analytics_enabled');
  }

  disable() {
    this.track('analytics_disabled');
    this.flushEvents();
    this.isEnabled = false;
  }

  isAnalyticsEnabled() {
    return this.isEnabled;
  }

  getSessionId() {
    return this.sessionId;
  }

  getUserJourney() {
    return [...this.userJourney];
  }

  getCostMetrics() {
    return new Map(this.costMetrics);
  }

  getQueuedEventsCount() {
    return this.events.length;
  }

  // Real-time cost analytics
  startCostTracking() {
    this.costTrackingInterval = setInterval(() => {
      this.trackResourceUsage('memory', this.getMemoryUsage());
      this.trackResourceUsage('network', this.getNetworkUsage());
    }, 10000); // Every 10 seconds
  }

  stopCostTracking() {
    if (this.costTrackingInterval) {
      clearInterval(this.costTrackingInterval);
      this.costTrackingInterval = null;
    }
  }

  getMemoryUsage() {
    if (performance.memory) {
      return {
        used: performance.memory.usedJSHeapSize,
        total: performance.memory.totalJSHeapSize,
        limit: performance.memory.jsHeapSizeLimit,
        percentage: (performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit) * 100
      };
    }
    return null;
  }

  getNetworkUsage() {
    // This would typically integrate with service worker
    // to track actual network usage
    return {
      requests: this.networkRequests || 0,
      bytesTransferred: this.bytesTransferred || 0
    };
  }

  // Cleanup
  destroy() {
    this.flushEvents();
    this.stopCostTracking();
    
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
  }
}

// Analytics utilities
export function trackEvent(eventName, properties) {
  const analyticsManager = window.LostFoundApp?.analytics;
  if (analyticsManager) {
    analyticsManager.track(eventName, properties);
  }
}

export function trackPageView(path, title) {
  const analyticsManager = window.LostFoundApp?.analytics;
  if (analyticsManager) {
    analyticsManager.trackPageView(path, title);
  }
}

export function trackUserAction(action, target, properties) {
  const analyticsManager = window.LostFoundApp?.analytics;
  if (analyticsManager) {
    analyticsManager.trackUserAction(action, target, properties);
  }
}

export function setUserId(userId) {
  const analyticsManager = window.LostFoundApp?.analytics;
  if (analyticsManager) {
    analyticsManager.setUserId(userId);
  }
}