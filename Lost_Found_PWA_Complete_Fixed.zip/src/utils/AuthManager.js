// Authentication Manager for Lost & Found PWA
export class AuthManager {
  constructor() {
    this.user = null;
    this.token = null;
    this.refreshToken = null;
    this.isInitialized = false;
    this.authListeners = [];
    
    // API endpoints
    this.endpoints = {
      login: '/api/auth/login',
      register: '/api/auth/register',
      refresh: '/api/auth/refresh',
      logout: '/api/auth/logout',
      profile: '/api/auth/profile',
      googleAuth: '/api/auth/google',
      forgotPassword: '/api/auth/forgot-password',
      resetPassword: '/api/auth/reset-password'
    };
  }

  async init() {
    console.log('🔐 Initializing AuthManager...');
    
    try {
      // Load stored authentication data
      await this.loadStoredAuth();
      
      // Validate stored token
      if (this.token) {
        await this.validateToken();
      }
      
      // Setup token refresh timer
      this.setupTokenRefresh();
      
      this.isInitialized = true;
      console.log('✅ AuthManager initialized');
      
    } catch (error) {
      console.error('❌ AuthManager initialization failed:', error);
      await this.clearAuth();
    }
  }

  async loadStoredAuth() {
    try {
      // Load from localStorage
      const storedAuth = localStorage.getItem('lf_auth');
      if (storedAuth) {
        const authData = JSON.parse(storedAuth);
        this.token = authData.token;
        this.refreshToken = authData.refreshToken;
        this.user = authData.user;
      }
    } catch (error) {
      console.error('Failed to load stored auth:', error);
      localStorage.removeItem('lf_auth');
    }
  }

  async saveAuth(authData) {
    try {
      this.token = authData.token;
      this.refreshToken = authData.refreshToken;
      this.user = authData.user;
      
      // Save to localStorage
      localStorage.setItem('lf_auth', JSON.stringify({
        token: this.token,
        refreshToken: this.refreshToken,
        user: this.user,
        timestamp: Date.now()
      }));
      
      // Notify listeners
      this.notifyAuthChange();
      
    } catch (error) {
      console.error('Failed to save auth:', error);
    }
  }

  async clearAuth() {
    this.token = null;
    this.refreshToken = null;
    this.user = null;
    
    // Clear localStorage
    localStorage.removeItem('lf_auth');
    
    // Notify listeners
    this.notifyAuthChange();
  }

  async validateToken() {
    if (!this.token) return false;
    
    try {
      const response = await this.apiCall(this.endpoints.profile, {
        method: 'GET'
      });
      
      if (response.ok) {
        const userData = await response.json();
        this.user = userData;
        return true;
      } else {
        // Token is invalid, try to refresh
        return await this.refreshAuthToken();
      }
    } catch (error) {
      console.error('Token validation failed:', error);
      return false;
    }
  }

  async refreshAuthToken() {
    if (!this.refreshToken) return false;
    
    try {
      const response = await fetch(this.endpoints.refresh, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          refreshToken: this.refreshToken
        })
      });
      
      if (response.ok) {
        const authData = await response.json();
        await this.saveAuth(authData);
        return true;
      } else {
        await this.clearAuth();
        return false;
      }
    } catch (error) {
      console.error('Token refresh failed:', error);
      await this.clearAuth();
      return false;
    }
  }

  setupTokenRefresh() {
    // Refresh token every 50 minutes (assuming 1-hour expiry)
    setInterval(async () => {
      if (this.token) {
        await this.refreshAuthToken();
      }
    }, 50 * 60 * 1000);
  }

  // Authentication methods
  async login(credentials) {
    try {
      const response = await fetch(this.endpoints.login, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        await this.saveAuth(data);
        return { success: true, user: this.user };
      } else {
        return { success: false, error: data.message || 'Login failed' };
      }
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async register(userData) {
    try {
      const response = await fetch(this.endpoints.register, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        await this.saveAuth(data);
        return { success: true, user: this.user };
      } else {
        return { success: false, error: data.message || 'Registration failed' };
      }
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async logout() {
    try {
      // Call logout endpoint if authenticated
      if (this.token) {
        await this.apiCall(this.endpoints.logout, {
          method: 'POST'
        });
      }
    } catch (error) {
      console.error('Logout API error:', error);
    } finally {
      // Always clear local auth data
      await this.clearAuth();
    }
  }

  async googleLogin() {
    try {
      // Open Google OAuth popup
      const popup = window.open(
        this.endpoints.googleAuth,
        'google-auth',
        'width=500,height=600,scrollbars=yes,resizable=yes'
      );
      
      // Listen for auth completion
      return new Promise((resolve, reject) => {
        const checkClosed = setInterval(() => {
          if (popup.closed) {
            clearInterval(checkClosed);
            reject(new Error('Authentication cancelled'));
          }
        }, 1000);
        
        // Listen for message from popup
        const messageHandler = async (event) => {
          if (event.origin !== window.location.origin) return;
          
          if (event.data.type === 'GOOGLE_AUTH_SUCCESS') {
            clearInterval(checkClosed);
            window.removeEventListener('message', messageHandler);
            popup.close();
            
            await this.saveAuth(event.data.authData);
            resolve({ success: true, user: this.user });
          } else if (event.data.type === 'GOOGLE_AUTH_ERROR') {
            clearInterval(checkClosed);
            window.removeEventListener('message', messageHandler);
            popup.close();
            
            reject(new Error(event.data.error || 'Google authentication failed'));
          }
        };
        
        window.addEventListener('message', messageHandler);
      });
    } catch (error) {
      console.error('Google login error:', error);
      return { success: false, error: error.message };
    }
  }

  async forgotPassword(email) {
    try {
      const response = await fetch(this.endpoints.forgotPassword, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return { success: true, message: data.message };
      } else {
        return { success: false, error: data.message || 'Failed to send reset email' };
      }
    } catch (error) {
      console.error('Forgot password error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async resetPassword(token, newPassword) {
    try {
      const response = await fetch(this.endpoints.resetPassword, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ token, password: newPassword })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return { success: true, message: data.message };
      } else {
        return { success: false, error: data.message || 'Password reset failed' };
      }
    } catch (error) {
      console.error('Reset password error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async updateProfile(profileData) {
    try {
      const response = await this.apiCall(this.endpoints.profile, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(profileData)
      });
      
      if (response.ok) {
        const updatedUser = await response.json();
        this.user = { ...this.user, ...updatedUser };
        
        // Update stored auth data
        const storedAuth = JSON.parse(localStorage.getItem('lf_auth') || '{}');
        storedAuth.user = this.user;
        localStorage.setItem('lf_auth', JSON.stringify(storedAuth));
        
        this.notifyAuthChange();
        return { success: true, user: this.user };
      } else {
        const error = await response.json();
        return { success: false, error: error.message || 'Profile update failed' };
      }
    } catch (error) {
      console.error('Profile update error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  // Utility methods
  async apiCall(url, options = {}) {
    const headers = {
      ...options.headers
    };
    
    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }
    
    const response = await fetch(url, {
      ...options,
      headers
    });
    
    // Handle token expiry
    if (response.status === 401 && this.token) {
      const refreshed = await this.refreshAuthToken();
      if (refreshed) {
        // Retry the request with new token
        headers.Authorization = `Bearer ${this.token}`;
        return fetch(url, { ...options, headers });
      } else {
        // Refresh failed, redirect to login
        await this.clearAuth();
        if (window.LostFoundApp?.router) {
          window.LostFoundApp.router.navigate('/login');
        }
      }
    }
    
    return response;
  }

  // State getters
  isAuthenticated() {
    return !!this.token && !!this.user;
  }

  getUser() {
    return this.user;
  }

  getToken() {
    return this.token;
  }

  isAdmin() {
    return this.user?.role === 'admin' || this.user?.permissions?.includes('admin');
  }

  isModerator() {
    return this.user?.role === 'moderator' || this.user?.permissions?.includes('moderate');
  }

  hasPermission(permission) {
    if (!this.user) return false;
    return this.user.permissions?.includes(permission) || this.isAdmin();
  }

  // Event handling
  onAuthChange(callback) {
    this.authListeners.push(callback);
    
    // Return unsubscribe function
    return () => {
      const index = this.authListeners.indexOf(callback);
      if (index > -1) {
        this.authListeners.splice(index, 1);
      }
    };
  }

  notifyAuthChange() {
    this.authListeners.forEach(callback => {
      try {
        callback({
          isAuthenticated: this.isAuthenticated(),
          user: this.user,
          token: this.token
        });
      } catch (error) {
        console.error('Auth listener error:', error);
      }
    });
  }

  // Guest mode
  async enableGuestMode() {
    const guestUser = {
      id: `guest_${Date.now()}`,
      name: 'Guest User',
      email: null,
      role: 'guest',
      permissions: ['view', 'report'],
      isGuest: true
    };
    
    this.user = guestUser;
    this.notifyAuthChange();
    
    return { success: true, user: guestUser };
  }

  isGuest() {
    return this.user?.isGuest === true;
  }

  // Session management
  async checkAuthState() {
    if (!this.isInitialized) {
      await this.init();
    }
    
    return {
      isAuthenticated: this.isAuthenticated(),
      user: this.user,
      isGuest: this.isGuest()
    };
  }

  getAuthHeaders() {
    return this.token ? { Authorization: `Bearer ${this.token}` } : {};
  }
}

// Auth utilities
export function requireAuth() {
  const authManager = window.LostFoundApp?.auth;
  if (!authManager || !authManager.isAuthenticated()) {
    if (window.LostFoundApp?.router) {
      window.LostFoundApp.router.navigate('/login');
    }
    return false;
  }
  return true;
}

export function requireAdmin() {
  const authManager = window.LostFoundApp?.auth;
  if (!authManager || !authManager.isAdmin()) {
    if (window.LostFoundApp?.router) {
      window.LostFoundApp.router.navigate('/dashboard');
    }
    return false;
  }
  return true;
}

export function getCurrentUser() {
  const authManager = window.LostFoundApp?.auth;
  return authManager?.getUser() || null;
}

export function isAuthenticated() {
  const authManager = window.LostFoundApp?.auth;
  return authManager?.isAuthenticated() || false;
}