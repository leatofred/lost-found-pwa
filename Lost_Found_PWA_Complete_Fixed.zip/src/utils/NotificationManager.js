// Notification Manager for Lost & Found PWA
export class NotificationManager {
  constructor() {
    this.permission = 'default';
    this.isSupported = 'Notification' in window;
    this.registration = null;
    this.vapidPublicKey = 'BEl62iUYgUivxIkv69yViEuiBIa40HI6YrrfuWKOjr_8jGqqDpD7RJXfQjdIcJL2UGXaVDdkfV3ZmPBnpTyqBVs'; // Replace with your VAPID key
    this.subscriptions = new Map();
    this.notificationQueue = [];
    this.isOnline = navigator.onLine;
  }

  async init() {
    console.log('🔔 Initializing NotificationManager...');
    
    if (!this.isSupported) {
      console.warn('Notifications not supported in this browser');
      return;
    }

    try {
      // Get current permission status
      this.permission = Notification.permission;
      
      // Get service worker registration
      if ('serviceWorker' in navigator) {
        this.registration = await navigator.serviceWorker.ready;
      }
      
      // Setup push subscription if permission granted
      if (this.permission === 'granted') {
        await this.setupPushSubscription();
      }
      
      // Setup online/offline listeners
      this.setupNetworkListeners();
      
      // Process any queued notifications
      this.processNotificationQueue();
      
      console.log('✅ NotificationManager initialized');
      
    } catch (error) {
      console.error('❌ NotificationManager initialization failed:', error);
    }
  }

  async requestPermission() {
    if (!this.isSupported) {
      return { success: false, error: 'Notifications not supported' };
    }

    try {
      const permission = await Notification.requestPermission();
      this.permission = permission;
      
      if (permission === 'granted') {
        await this.setupPushSubscription();
        return { success: true, permission };
      } else {
        return { success: false, error: 'Permission denied', permission };
      }
    } catch (error) {
      console.error('Permission request failed:', error);
      return { success: false, error: error.message };
    }
  }

  async setupPushSubscription() {
    if (!this.registration) return;

    try {
      // Check if already subscribed
      let subscription = await this.registration.pushManager.getSubscription();
      
      if (!subscription) {
        // Create new subscription
        subscription = await this.registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: this.urlBase64ToUint8Array(this.vapidPublicKey)
        });
      }
      
      // Send subscription to server
      await this.sendSubscriptionToServer(subscription);
      
      console.log('Push subscription setup complete');
      
    } catch (error) {
      console.error('Push subscription setup failed:', error);
    }
  }

  async sendSubscriptionToServer(subscription) {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = {
        'Content-Type': 'application/json',
        ...authManager?.getAuthHeaders()
      };
      
      const response = await fetch('/api/notifications/subscribe', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          subscription,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString()
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to send subscription to server');
      }
      
    } catch (error) {
      console.error('Failed to send subscription to server:', error);
    }
  }

  // Local notifications
  async showNotification(title, options = {}) {
    if (this.permission !== 'granted') {
      console.warn('Notification permission not granted');
      return;
    }

    const defaultOptions = {
      icon: '/icons/icon-192x192.png',
      badge: '/icons/badge-72x72.png',
      vibrate: [100, 50, 100],
      requireInteraction: false,
      silent: false,
      timestamp: Date.now(),
      ...options
    };

    try {
      if (this.registration) {
        // Use service worker for better reliability
        await this.registration.showNotification(title, defaultOptions);
      } else {
        // Fallback to regular notification
        new Notification(title, defaultOptions);
      }
      
      // Track notification
      this.trackNotification('shown', { title, ...defaultOptions });
      
    } catch (error) {
      console.error('Failed to show notification:', error);
      
      // Queue for later if offline
      if (!this.isOnline) {
        this.queueNotification(title, defaultOptions);
      }
    }
  }

  // Predefined notification types
  async showItemMatchNotification(item, match) {
    await this.showNotification('Item Match Found!', {
      body: `We found a potential match for your ${item.category}: "${item.title}"`,
      icon: '/icons/match-found.png',
      tag: `match-${item.id}`,
      data: {
        type: 'item_match',
        itemId: item.id,
        matchId: match.id,
        url: `/item/${item.id}`
      },
      actions: [
        {
          action: 'view',
          title: 'View Match',
          icon: '/icons/action-view.png'
        },
        {
          action: 'dismiss',
          title: 'Dismiss',
          icon: '/icons/action-dismiss.png'
        }
      ],
      requireInteraction: true
    });
  }

  async showMessageNotification(message) {
    await this.showNotification('New Message', {
      body: `${message.senderName}: ${message.preview}`,
      icon: message.senderAvatar || '/icons/message.png',
      tag: `message-${message.id}`,
      data: {
        type: 'message',
        messageId: message.id,
        senderId: message.senderId,
        url: `/messages?conversation=${message.conversationId}`
      },
      actions: [
        {
          action: 'reply',
          title: 'Reply',
          icon: '/icons/action-reply.png'
        },
        {
          action: 'view',
          title: 'View',
          icon: '/icons/action-view.png'
        }
      ]
    });
  }

  async showItemStatusNotification(item, status) {
    const statusMessages = {
      found: 'Your lost item has been found!',
      claimed: 'Your found item has been claimed!',
      expired: 'Your item listing has expired',
      approved: 'Your item has been approved',
      rejected: 'Your item submission needs attention'
    };

    await this.showNotification('Item Status Update', {
      body: statusMessages[status] || 'Your item status has been updated',
      icon: '/icons/status-update.png',
      tag: `status-${item.id}`,
      data: {
        type: 'status_update',
        itemId: item.id,
        status,
        url: `/item/${item.id}`
      },
      actions: [
        {
          action: 'view',
          title: 'View Item',
          icon: '/icons/action-view.png'
        }
      ]
    });
  }

  async showSystemNotification(title, message, type = 'info') {
    const icons = {
      info: '/icons/info.png',
      warning: '/icons/warning.png',
      error: '/icons/error.png',
      success: '/icons/success.png'
    };

    await this.showNotification(title, {
      body: message,
      icon: icons[type] || icons.info,
      tag: `system-${Date.now()}`,
      data: {
        type: 'system',
        category: type
      }
    });
  }

  // Notification scheduling
  scheduleNotification(title, options, delay) {
    setTimeout(() => {
      this.showNotification(title, options);
    }, delay);
  }

  scheduleRecurringNotification(title, options, interval) {
    return setInterval(() => {
      this.showNotification(title, options);
    }, interval);
  }

  // Notification management
  async clearNotification(tag) {
    if (this.registration) {
      const notifications = await this.registration.getNotifications({ tag });
      notifications.forEach(notification => notification.close());
    }
  }

  async clearAllNotifications() {
    if (this.registration) {
      const notifications = await this.registration.getNotifications();
      notifications.forEach(notification => notification.close());
    }
  }

  async getActiveNotifications() {
    if (this.registration) {
      return await this.registration.getNotifications();
    }
    return [];
  }

  // Notification preferences
  async updateNotificationPreferences(preferences) {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = {
        'Content-Type': 'application/json',
        ...authManager?.getAuthHeaders()
      };
      
      const response = await fetch('/api/notifications/preferences', {
        method: 'PUT',
        headers,
        body: JSON.stringify(preferences)
      });
      
      if (response.ok) {
        this.preferences = preferences;
        return { success: true };
      } else {
        throw new Error('Failed to update preferences');
      }
    } catch (error) {
      console.error('Failed to update notification preferences:', error);
      return { success: false, error: error.message };
    }
  }

  async getNotificationPreferences() {
    try {
      const authManager = window.LostFoundApp?.auth;
      const headers = authManager?.getAuthHeaders();
      
      const response = await fetch('/api/notifications/preferences', {
        headers
      });
      
      if (response.ok) {
        this.preferences = await response.json();
        return this.preferences;
      } else {
        throw new Error('Failed to get preferences');
      }
    } catch (error) {
      console.error('Failed to get notification preferences:', error);
      return this.getDefaultPreferences();
    }
  }

  getDefaultPreferences() {
    return {
      itemMatches: true,
      messages: true,
      statusUpdates: true,
      systemNotifications: true,
      emailNotifications: true,
      pushNotifications: true,
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00'
      },
      frequency: {
        immediate: true,
        digest: false,
        weekly: false
      }
    };
  }

  // Offline support
  queueNotification(title, options) {
    this.notificationQueue.push({
      title,
      options,
      timestamp: Date.now()
    });
    
    // Limit queue size
    if (this.notificationQueue.length > 50) {
      this.notificationQueue.shift();
    }
  }

  async processNotificationQueue() {
    if (!this.isOnline || this.notificationQueue.length === 0) return;

    const queue = [...this.notificationQueue];
    this.notificationQueue = [];

    for (const notification of queue) {
      try {
        await this.showNotification(notification.title, notification.options);
      } catch (error) {
        console.error('Failed to process queued notification:', error);
      }
    }
  }

  setupNetworkListeners() {
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.processNotificationQueue();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
    });
  }

  // Analytics and tracking
  trackNotification(action, data) {
    if (window.LostFoundApp?.analytics) {
      window.LostFoundApp.analytics.track(`notification_${action}`, {
        ...data,
        timestamp: new Date().toISOString(),
        permission: this.permission,
        isSupported: this.isSupported
      });
    }
  }

  // Utility methods
  urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  isQuietHours() {
    if (!this.preferences?.quietHours?.enabled) return false;

    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const [startHour, startMin] = this.preferences.quietHours.start.split(':').map(Number);
    const [endHour, endMin] = this.preferences.quietHours.end.split(':').map(Number);
    
    const startTime = startHour * 60 + startMin;
    const endTime = endHour * 60 + endMin;

    if (startTime <= endTime) {
      return currentTime >= startTime && currentTime <= endTime;
    } else {
      // Crosses midnight
      return currentTime >= startTime || currentTime <= endTime;
    }
  }

  // Public API
  async checkForUpdates() {
    try {
      const authManager = window.LostFoundApp?.auth;
      if (!authManager?.isAuthenticated()) return;

      const headers = authManager.getAuthHeaders();
      const response = await fetch('/api/notifications/check', { headers });
      
      if (response.ok) {
        const updates = await response.json();
        
        // Process each update
        for (const update of updates) {
          await this.processUpdate(update);
        }
      }
    } catch (error) {
      console.error('Failed to check for updates:', error);
    }
  }

  async processUpdate(update) {
    switch (update.type) {
      case 'item_match':
        await this.showItemMatchNotification(update.item, update.match);
        break;
      case 'message':
        await this.showMessageNotification(update.message);
        break;
      case 'status_update':
        await this.showItemStatusNotification(update.item, update.status);
        break;
      case 'system':
        await this.showSystemNotification(update.title, update.message, update.category);
        break;
    }
  }

  // Getters
  isPermissionGranted() {
    return this.permission === 'granted';
  }

  isSupported() {
    return this.isSupported;
  }

  getPermissionStatus() {
    return this.permission;
  }
}

// Notification utilities
export function requestNotificationPermission() {
  const notificationManager = window.LostFoundApp?.notifications;
  return notificationManager?.requestPermission() || Promise.resolve({ success: false });
}

export function showNotification(title, options) {
  const notificationManager = window.LostFoundApp?.notifications;
  return notificationManager?.showNotification(title, options);
}

export function isNotificationSupported() {
  return 'Notification' in window;
}

export function getNotificationPermission() {
  return Notification?.permission || 'default';
}