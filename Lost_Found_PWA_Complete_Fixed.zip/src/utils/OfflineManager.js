// Offline Manager for Lost & Found PWA
export class OfflineManager {
  constructor() {
    this.isOnline = navigator.onLine;
    this.offlineQueue = [];
    this.syncInProgress = false;
    this.dbName = 'LostFoundOfflineDB';
    this.dbVersion = 1;
    this.db = null;
    this.maxQueueSize = 100;
    this.syncRetryDelay = 5000; // 5 seconds
    this.maxRetries = 3;
  }

  async init() {
    console.log('📱 Initializing OfflineManager...');
    
    try {
      // Initialize IndexedDB
      await this.initDatabase();
      
      // Setup network listeners
      this.setupNetworkListeners();
      
      // Load offline queue from storage
      await this.loadOfflineQueue();
      
      // Register background sync if supported
      this.registerBackgroundSync();
      
      // Setup periodic sync
      this.setupPeriodicSync();
      
      console.log('✅ OfflineManager initialized');
      
    } catch (error) {
      console.error('❌ OfflineManager initialization failed:', error);
    }
  }

  async initDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // Create object stores
        if (!db.objectStoreNames.contains('offlineQueue')) {
          const queueStore = db.createObjectStore('offlineQueue', { 
            keyPath: 'id', 
            autoIncrement: true 
          });
          queueStore.createIndex('timestamp', 'timestamp');
          queueStore.createIndex('type', 'type');
          queueStore.createIndex('status', 'status');
        }
        
        if (!db.objectStoreNames.contains('cachedItems')) {
          const itemsStore = db.createObjectStore('cachedItems', { 
            keyPath: 'id' 
          });
          itemsStore.createIndex('category', 'category');
          itemsStore.createIndex('status', 'status');
          itemsStore.createIndex('lastModified', 'lastModified');
        }
        
        if (!db.objectStoreNames.contains('userPreferences')) {
          db.createObjectStore('userPreferences', { 
            keyPath: 'key' 
          });
        }
        
        if (!db.objectStoreNames.contains('searchHistory')) {
          const searchStore = db.createObjectStore('searchHistory', { 
            keyPath: 'id', 
            autoIncrement: true 
          });
          searchStore.createIndex('query', 'query');
          searchStore.createIndex('timestamp', 'timestamp');
        }
      };
    });
  }

  setupNetworkListeners() {
    window.addEventListener('online', async () => {
      console.log('📶 Connection restored');
      this.isOnline = true;
      
      // Sync offline data
      await this.syncOfflineData();
      
      // Notify app
      this.notifyNetworkChange(true);
    });

    window.addEventListener('offline', () => {
      console.log('📵 Connection lost');
      this.isOnline = false;
      
      // Notify app
      this.notifyNetworkChange(false);
    });
  }

  // Offline queue management
  async addToOfflineQueue(action) {
    const queueItem = {
      ...action,
      id: Date.now() + Math.random(),
      timestamp: new Date().toISOString(),
      status: 'pending',
      retries: 0,
      maxRetries: this.maxRetries
    };

    try {
      // Add to IndexedDB
      await this.dbTransaction('offlineQueue', 'readwrite', (store) => {
        store.add(queueItem);
      });
      
      // Add to memory queue
      this.offlineQueue.push(queueItem);
      
      // Limit queue size
      if (this.offlineQueue.length > this.maxQueueSize) {
        await this.removeOldestQueueItem();
      }
      
      console.log('Added to offline queue:', queueItem.type);
      
    } catch (error) {
      console.error('Failed to add to offline queue:', error);
    }
  }

  async loadOfflineQueue() {
    try {
      const items = await this.dbTransaction('offlineQueue', 'readonly', (store) => {
        return store.getAll();
      });
      
      this.offlineQueue = items.filter(item => item.status === 'pending');
      console.log(`Loaded ${this.offlineQueue.length} items from offline queue`);
      
    } catch (error) {
      console.error('Failed to load offline queue:', error);
    }
  }

  async removeOldestQueueItem() {
    if (this.offlineQueue.length === 0) return;
    
    const oldest = this.offlineQueue.shift();
    
    try {
      await this.dbTransaction('offlineQueue', 'readwrite', (store) => {
        store.delete(oldest.id);
      });
    } catch (error) {
      console.error('Failed to remove oldest queue item:', error);
    }
  }

  async syncOfflineData() {
    if (this.syncInProgress || !this.isOnline || this.offlineQueue.length === 0) {
      return;
    }

    this.syncInProgress = true;
    console.log(`🔄 Syncing ${this.offlineQueue.length} offline items...`);

    const itemsToSync = [...this.offlineQueue];
    let syncedCount = 0;
    let failedCount = 0;

    for (const item of itemsToSync) {
      try {
        const success = await this.syncQueueItem(item);
        
        if (success) {
          await this.markItemSynced(item);
          syncedCount++;
        } else {
          await this.incrementRetryCount(item);
          failedCount++;
        }
      } catch (error) {
        console.error('Sync error for item:', item.id, error);
        await this.incrementRetryCount(item);
        failedCount++;
      }
    }

    // Remove synced items from memory queue
    this.offlineQueue = this.offlineQueue.filter(item => item.status === 'pending');

    this.syncInProgress = false;
    console.log(`✅ Sync complete: ${syncedCount} synced, ${failedCount} failed`);

    // Notify app of sync completion
    this.notifySyncComplete(syncedCount, failedCount);
  }

  async syncQueueItem(item) {
    const authManager = window.LostFoundApp?.auth;
    const headers = {
      'Content-Type': 'application/json',
      ...authManager?.getAuthHeaders()
    };

    try {
      let response;
      
      switch (item.type) {
        case 'create_item':
          response = await fetch('/api/items', {
            method: 'POST',
            headers,
            body: JSON.stringify(item.data)
          });
          break;
          
        case 'update_item':
          response = await fetch(`/api/items/${item.itemId}`, {
            method: 'PUT',
            headers,
            body: JSON.stringify(item.data)
          });
          break;
          
        case 'delete_item':
          response = await fetch(`/api/items/${item.itemId}`, {
            method: 'DELETE',
            headers
          });
          break;
          
        case 'send_message':
          response = await fetch('/api/messages', {
            method: 'POST',
            headers,
            body: JSON.stringify(item.data)
          });
          break;
          
        case 'update_profile':
          response = await fetch('/api/auth/profile', {
            method: 'PUT',
            headers,
            body: JSON.stringify(item.data)
          });
          break;
          
        default:
          console.warn('Unknown sync item type:', item.type);
          return false;
      }
      
      return response.ok;
      
    } catch (error) {
      console.error('Sync request failed:', error);
      return false;
    }
  }

  async markItemSynced(item) {
    try {
      await this.dbTransaction('offlineQueue', 'readwrite', (store) => {
        const updatedItem = { ...item, status: 'synced', syncedAt: new Date().toISOString() };
        store.put(updatedItem);
      });
    } catch (error) {
      console.error('Failed to mark item as synced:', error);
    }
  }

  async incrementRetryCount(item) {
    item.retries++;
    
    if (item.retries >= item.maxRetries) {
      item.status = 'failed';
    }
    
    try {
      await this.dbTransaction('offlineQueue', 'readwrite', (store) => {
        store.put(item);
      });
    } catch (error) {
      console.error('Failed to update retry count:', error);
    }
  }

  // Caching methods
  async cacheItem(item) {
    try {
      const cachedItem = {
        ...item,
        cachedAt: new Date().toISOString(),
        lastModified: item.lastModified || new Date().toISOString()
      };
      
      await this.dbTransaction('cachedItems', 'readwrite', (store) => {
        store.put(cachedItem);
      });
      
    } catch (error) {
      console.error('Failed to cache item:', error);
    }
  }

  async getCachedItem(id) {
    try {
      return await this.dbTransaction('cachedItems', 'readonly', (store) => {
        return store.get(id);
      });
    } catch (error) {
      console.error('Failed to get cached item:', error);
      return null;
    }
  }

  async getCachedItems(filters = {}) {
    try {
      const items = await this.dbTransaction('cachedItems', 'readonly', (store) => {
        return store.getAll();
      });
      
      // Apply filters
      return items.filter(item => {
        if (filters.category && item.category !== filters.category) return false;
        if (filters.status && item.status !== filters.status) return false;
        if (filters.search) {
          const searchTerm = filters.search.toLowerCase();
          return item.title?.toLowerCase().includes(searchTerm) ||
                 item.description?.toLowerCase().includes(searchTerm);
        }
        return true;
      });
      
    } catch (error) {
      console.error('Failed to get cached items:', error);
      return [];
    }
  }

  async clearExpiredCache() {
    const expiryTime = 24 * 60 * 60 * 1000; // 24 hours
    const cutoffTime = new Date(Date.now() - expiryTime).toISOString();
    
    try {
      await this.dbTransaction('cachedItems', 'readwrite', (store) => {
        const index = store.index('lastModified');
        const range = IDBKeyRange.upperBound(cutoffTime);
        
        index.openCursor(range).onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor) {
            cursor.delete();
            cursor.continue();
          }
        };
      });
    } catch (error) {
      console.error('Failed to clear expired cache:', error);
    }
  }

  // User preferences
  async savePreference(key, value) {
    try {
      await this.dbTransaction('userPreferences', 'readwrite', (store) => {
        store.put({ key, value, updatedAt: new Date().toISOString() });
      });
    } catch (error) {
      console.error('Failed to save preference:', error);
    }
  }

  async getPreference(key, defaultValue = null) {
    try {
      const result = await this.dbTransaction('userPreferences', 'readonly', (store) => {
        return store.get(key);
      });
      
      return result ? result.value : defaultValue;
    } catch (error) {
      console.error('Failed to get preference:', error);
      return defaultValue;
    }
  }

  // Search history
  async saveSearchQuery(query, filters = {}) {
    try {
      const searchItem = {
        query,
        filters,
        timestamp: new Date().toISOString()
      };
      
      await this.dbTransaction('searchHistory', 'readwrite', (store) => {
        store.add(searchItem);
      });
      
      // Limit search history
      await this.limitSearchHistory();
      
    } catch (error) {
      console.error('Failed to save search query:', error);
    }
  }

  async getSearchHistory(limit = 10) {
    try {
      const items = await this.dbTransaction('searchHistory', 'readonly', (store) => {
        const index = store.index('timestamp');
        return new Promise((resolve) => {
          const results = [];
          index.openCursor(null, 'prev').onsuccess = (event) => {
            const cursor = event.target.result;
            if (cursor && results.length < limit) {
              results.push(cursor.value);
              cursor.continue();
            } else {
              resolve(results);
            }
          };
        });
      });
      
      return items;
    } catch (error) {
      console.error('Failed to get search history:', error);
      return [];
    }
  }

  async limitSearchHistory(maxItems = 50) {
    try {
      const items = await this.dbTransaction('searchHistory', 'readonly', (store) => {
        return store.getAll();
      });
      
      if (items.length > maxItems) {
        const itemsToDelete = items
          .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
          .slice(0, items.length - maxItems);
        
        await this.dbTransaction('searchHistory', 'readwrite', (store) => {
          itemsToDelete.forEach(item => store.delete(item.id));
        });
      }
    } catch (error) {
      console.error('Failed to limit search history:', error);
    }
  }

  // Background sync
  registerBackgroundSync() {
    if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
      navigator.serviceWorker.ready.then((registration) => {
        return registration.sync.register('background-sync-items');
      }).catch((error) => {
        console.error('Background sync registration failed:', error);
      });
    }
  }

  setupPeriodicSync() {
    // Sync every 5 minutes when online
    setInterval(() => {
      if (this.isOnline && !this.syncInProgress) {
        this.syncOfflineData();
      }
    }, 5 * 60 * 1000);
    
    // Clear expired cache every hour
    setInterval(() => {
      this.clearExpiredCache();
    }, 60 * 60 * 1000);
  }

  // Database transaction helper
  async dbTransaction(storeName, mode, callback) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error('Database not initialized'));
        return;
      }
      
      const transaction = this.db.transaction([storeName], mode);
      const store = transaction.objectStore(storeName);
      
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(new Error('Transaction aborted'));
      
      try {
        const result = callback(store);
        
        if (result && typeof result.then === 'function') {
          // Handle promise-based operations
          result.then(resolve).catch(reject);
        } else if (result && result.onsuccess !== undefined) {
          // Handle IDB request objects
          result.onsuccess = () => resolve(result.result);
          result.onerror = () => reject(result.error);
        } else {
          // Handle synchronous operations
          transaction.oncomplete = () => resolve(result);
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  // Event handling
  notifyNetworkChange(isOnline) {
    const event = new CustomEvent('networkchange', {
      detail: { isOnline }
    });
    window.dispatchEvent(event);
  }

  notifySyncComplete(syncedCount, failedCount) {
    const event = new CustomEvent('syncomplete', {
      detail: { syncedCount, failedCount }
    });
    window.dispatchEvent(event);
  }

  // Public API
  isOnlineStatus() {
    return this.isOnline;
  }

  getQueueSize() {
    return this.offlineQueue.length;
  }

  async getOfflineStats() {
    try {
      const queueItems = await this.dbTransaction('offlineQueue', 'readonly', (store) => {
        return store.getAll();
      });
      
      const cachedItems = await this.dbTransaction('cachedItems', 'readonly', (store) => {
        return store.getAll();
      });
      
      return {
        queueSize: this.offlineQueue.length,
        totalQueueItems: queueItems.length,
        cachedItems: cachedItems.length,
        syncInProgress: this.syncInProgress,
        isOnline: this.isOnline
      };
    } catch (error) {
      console.error('Failed to get offline stats:', error);
      return {
        queueSize: 0,
        totalQueueItems: 0,
        cachedItems: 0,
        syncInProgress: false,
        isOnline: this.isOnline
      };
    }
  }

  async clearAllData() {
    try {
      await this.dbTransaction('offlineQueue', 'readwrite', (store) => {
        store.clear();
      });
      
      await this.dbTransaction('cachedItems', 'readwrite', (store) => {
        store.clear();
      });
      
      await this.dbTransaction('searchHistory', 'readwrite', (store) => {
        store.clear();
      });
      
      this.offlineQueue = [];
      console.log('All offline data cleared');
      
    } catch (error) {
      console.error('Failed to clear offline data:', error);
    }
  }
}

// Offline utilities
export function addOfflineAction(type, data, itemId = null) {
  const offlineManager = window.LostFoundApp?.offline;
  if (offlineManager) {
    return offlineManager.addToOfflineQueue({ type, data, itemId });
  }
}

export function isOnline() {
  const offlineManager = window.LostFoundApp?.offline;
  return offlineManager?.isOnlineStatus() ?? navigator.onLine;
}

export function getOfflineQueueSize() {
  const offlineManager = window.LostFoundApp?.offline;
  return offlineManager?.getQueueSize() ?? 0;
}

export function syncOfflineData() {
  const offlineManager = window.LostFoundApp?.offline;
  return offlineManager?.syncOfflineData();
}